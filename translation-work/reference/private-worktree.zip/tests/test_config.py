from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from localization.cli import build_parser
from localization.config import DEFAULT_BATCH_SIZE, DEFAULT_MAX_BATCH_CHARS, ProviderConfig
from localization.errors import ConfigurationError


class ConfigurationTests(unittest.TestCase):
    def test_cli_uses_conservative_default_batch_limits(self) -> None:
        args = build_parser().parse_args([])

        self.assertEqual(DEFAULT_BATCH_SIZE, 10)
        self.assertEqual(DEFAULT_MAX_BATCH_CHARS, 2_000)
        self.assertEqual(args.batch_size, 10)
        self.assertEqual(args.max_batch_chars, 2_000)

    def test_cli_overrides_environment_and_blank_glossary_model_uses_translation_model(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            dotenv = Path(temporary_directory) / ".env"
            dotenv.write_text(
                "API_KEY=dotenv-key\n"
                "TRANSLATION_BASE_URL=https://dotenv.example/v1\n"
                "TRANSLATION_MODEL=dotenv-model\n",
                encoding="utf-8",
            )
            config = ProviderConfig.from_sources(
                cli={
                    "reasoning_effort": "high",
                    "max_response_size": 1234,
                    "timeout": 45,
                    "retries": 0,
                },
                environment={
                    "API_KEY": "environment-key",
                    "TRANSLATION_BASE_URL": "https://environment.example/v1",
                    "TRANSLATION_MODEL": "environment-model",
                    "GLOSSARY_MODEL": "",
                    "TRANSLATION_REASONING_EFFORT": "none",
                },
                dotenv_path=dotenv,
            )

        self.assertEqual(config.api_key, "environment-key")
        self.assertEqual(config.base_url, "https://environment.example/v1")
        self.assertEqual(config.translation_model, "environment-model")
        self.assertEqual(config.glossary_model, "environment-model")
        self.assertEqual(config.reasoning_effort, "high")
        self.assertEqual(config.max_response_size, 1234)
        self.assertEqual(config.timeout, 45)
        self.assertEqual(config.retries, 0)

    def test_live_credentials_are_required_but_offline_configuration_is_allowed(self) -> None:
        cli = {
            "reasoning_effort": None,
            "max_response_size": None,
            "timeout": None,
            "retries": None,
        }
        with self.assertRaises(ConfigurationError):
            ProviderConfig.from_sources(cli=cli, environment={})

        offline = ProviderConfig.from_sources(cli=cli, environment={}, require_credentials=False)
        self.assertEqual(offline.glossary_model, offline.translation_model)


if __name__ == "__main__":
    unittest.main()
