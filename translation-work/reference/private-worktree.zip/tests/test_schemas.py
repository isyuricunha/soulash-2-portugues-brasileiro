from __future__ import annotations

import json
import unittest

from localization.errors import ValidationError
from localization.models import AcceptedTranslation
from localization.schemas import (
    parse_review_response,
    parse_translation_response,
    translation_schema,
)
from tests.helpers import make_unit


class SchemaTests(unittest.TestCase):
    def test_translation_schema_has_exact_ids_and_no_extra_fields(self) -> None:
        units = (make_unit("u1", "Sword", gender_eligible=True), make_unit("u2", "Shield"))

        schema = translation_schema(units, allow_terminology_decisions=True)

        self.assertFalse(schema["additionalProperties"])
        self.assertEqual(schema["properties"]["translations"]["required"], ["u1", "u2"])
        self.assertFalse(schema["properties"]["translations"]["additionalProperties"])
        self.assertEqual(schema["properties"]["grammatical_genders"]["required"], ["u1"])
        self.assertEqual(schema["properties"]["terminology_decisions"]["maxItems"], 3)

    def test_translation_parser_accepts_valid_items_and_isolates_invalid_items(self) -> None:
        units = (make_unit("u1", "Deal ::damage."), make_unit("u2", "Shield"))
        raw = json.dumps(
            {
                "translations": {"u1": "Cause __KEEP_0__.", "u2": ""},
                "grammatical_genders": {},
                "terminology_decisions": [],
            }
        )

        parsed = parse_translation_response(raw, units, allow_terminology_decisions=True)

        self.assertEqual(set(parsed.accepted), {"u1"})
        self.assertEqual(parsed.accepted["u1"].restored_text, "Cause ::damage.")
        self.assertIn("u2", parsed.errors)

    def test_invalid_glossary_metadata_does_not_discard_valid_translation_units(self) -> None:
        units = (make_unit("u1", "Sword"),)
        raw = json.dumps(
            {
                "translations": {"u1": "Espada"},
                "grammatical_genders": {},
                "terminology_decisions": [{"unexpected": "metadata"}],
            }
        )

        parsed = parse_translation_response(raw, units, allow_terminology_decisions=True)

        self.assertEqual(set(parsed.accepted), {"u1"})
        self.assertIsNotNone(parsed.metadata_error)
        self.assertFalse(parsed.terminology_decisions)

    def test_translation_parser_rejects_tokens_that_change_after_restoration(self) -> None:
        units = (make_unit("u1", "Strength +2, Willpower +2"),)
        raw = json.dumps(
            {
                "translations": {"u1": "Força __KEEP_0____KEEP_1__"},
                "grammatical_genders": {},
            }
        )

        parsed = parse_translation_response(raw, units, allow_terminology_decisions=False)

        self.assertFalse(parsed.accepted)
        self.assertIn("Restored technical-token mismatch", parsed.errors["u1"])

    def test_translation_parser_rejects_duplicate_keys_extra_ids_and_wrapping(self) -> None:
        units = (make_unit("u1", "Sword"),)
        responses = (
            '{"translations":{"u1":"Espada","u1":"Lâmina"},"grammatical_genders":{}}',
            '{"translations":{"u1":"Espada","u9":"Extra"},"grammatical_genders":{}}',
            '```json\n{"translations":{"u1":"Espada"},"grammatical_genders":{}}\n```',
        )
        for raw in responses:
            with self.subTest(raw=raw), self.assertRaises(ValidationError):
                parse_translation_response(raw, units, allow_terminology_decisions=False)

    def test_review_keep_is_exact_and_unknown_issue_normalizes_to_other(self) -> None:
        unit = make_unit("u1", "Deal ::damage.")
        current = {
            "u1": AcceptedTranslation(
                "u1", "Cause __KEEP_0__.", "Cause ::damage.", grammatical_gender=None
            )
        }
        raw = json.dumps(
            {
                "reviews": [
                    {
                        "id": "u1",
                        "decision": "keep",
                        "text": "Cause __KEEP_0__.",
                        "issue_codes": ["invented-label"],
                    }
                ]
            }
        )

        accepted, codes = parse_review_response(raw, (unit,), current)

        self.assertEqual(accepted["u1"], current["u1"])
        self.assertEqual(codes["u1"], ("other",))

        changed = raw.replace("Cause __KEEP_0__.", "Causa __KEEP_0__.")
        with self.assertRaises(ValidationError):
            parse_review_response(changed, (unit,), current)


if __name__ == "__main__":
    unittest.main()
