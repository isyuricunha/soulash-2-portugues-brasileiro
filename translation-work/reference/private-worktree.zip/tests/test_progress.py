from __future__ import annotations

import io
import json
import unittest

from localization.progress import LiveProgressReporter


class MutableClock:
    def __init__(self) -> None:
        self.value = 0.0

    def __call__(self) -> float:
        return self.value


class LiveProgressReporterTests(unittest.TestCase):
    def test_interactive_progress_updates_one_line_with_rate_and_eta(self) -> None:
        stream = io.StringIO()
        clock = MutableClock()
        reporter = LiveProgressReporter(
            progress_stream=stream,
            interactive=True,
            clock=clock,
        )

        reporter(
            {
                "event": "generation_started",
                "selected": 100,
                "reused": 0,
            }
        )
        clock.value = 10.0
        reporter(
            {
                "event": "batch_committed",
                "checkpoint_total": 20,
                "accepted_units_per_second": 2.0,
                "eta_seconds": 40.0,
            }
        )

        output_before_finish = stream.getvalue()
        self.assertNotIn("\n", output_before_finish)
        self.assertGreaterEqual(output_before_finish.count("\r"), 2)
        self.assertIn("20.0%", output_before_finish)
        self.assertIn("20/100", output_before_finish)
        self.assertIn("2.00 units/s", output_before_finish)
        self.assertIn("ETA 00:00:40", output_before_finish)

        reporter.finish()
        self.assertEqual(stream.getvalue().count("\n"), 1)

    def test_partial_progress_calculates_eta_without_batch_estimates(self) -> None:
        stream = io.StringIO()
        clock = MutableClock()
        reporter = LiveProgressReporter(
            progress_stream=stream,
            interactive=True,
            clock=clock,
        )
        reporter({"event": "generation_started", "selected": 30, "reused": 10})
        clock.value = 5.0
        reporter({"event": "partial_checkpoint_committed", "checkpoint_total": 15})

        output = stream.getvalue()
        self.assertIn("50.0%", output)
        self.assertIn("15/30", output)
        self.assertIn("1.00 units/s", output)
        self.assertIn("ETA 00:00:15", output)

    def test_noninteractive_output_is_clean_and_verbose_events_remain_json(self) -> None:
        progress_stream = io.StringIO()
        log_stream = io.StringIO()
        reporter = LiveProgressReporter(
            progress_stream=progress_stream,
            log_stream=log_stream,
            interactive=False,
            verbose=True,
        )
        event = {"event": "generation_started", "selected": 10, "reused": 0}

        reporter(event)
        reporter.finish()

        self.assertEqual(progress_stream.getvalue(), "")
        self.assertEqual(json.loads(log_stream.getvalue()), event)
        self.assertNotIn("\r", log_stream.getvalue())

    def test_interactive_verbose_event_redraws_active_progress(self) -> None:
        progress_stream = io.StringIO()
        log_stream = io.StringIO()
        reporter = LiveProgressReporter(
            progress_stream=progress_stream,
            log_stream=log_stream,
            interactive=True,
            verbose=True,
        )
        reporter({"event": "generation_started", "selected": 10, "reused": 0})

        reporter({"event": "glossary_worker_completed", "processed": 2})

        self.assertTrue(reporter.rendered)
        self.assertGreaterEqual(progress_stream.getvalue().count("Progress ["), 2)
        events = [json.loads(line) for line in log_stream.getvalue().splitlines()]
        self.assertEqual(events[-1]["event"], "glossary_worker_completed")

    def test_finish_is_idempotent_for_failure_cleanup(self) -> None:
        stream = io.StringIO()
        reporter = LiveProgressReporter(progress_stream=stream, interactive=True)
        reporter({"event": "generation_started", "selected": 10, "reused": 0})

        reporter.finish()
        reporter.finish()

        self.assertEqual(stream.getvalue().count("\n"), 1)


if __name__ == "__main__":
    unittest.main()
