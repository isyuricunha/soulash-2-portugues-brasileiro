from __future__ import annotations

import json
import sqlite3
import tempfile
import threading
import time
import unittest
from pathlib import Path

from localization.checkpoint import CheckpointStore
from localization.formats.soulash import SoulashFormatHandler
from localization.glossary import GlossaryStore
from localization.models import ProviderRequest, ProviderResponse
from localization.pipeline import LocalizationPipeline, PipelineSettings


class PipelineFakeProvider:
    def __init__(
        self,
        *,
        delays: dict[str, float] | None = None,
        failing_ids: set[str] | None = None,
    ) -> None:
        self.delays = delays or {}
        self.failing_ids = failing_ids or set()
        self.requests: list[ProviderRequest] = []
        self._lock = threading.Lock()
        self.in_flight = 0
        self.maximum_in_flight = 0
        self.active_operations: set[str] = set()
        self.glossary_translation_overlap = False

    def complete(self, request: ProviderRequest) -> ProviderResponse:
        payload = json.loads(request.messages[1]["content"])
        unit_ids = [unit["id"] for unit in payload.get("units", [])]
        delay = max((self.delays.get(unit_id, 0.02) for unit_id in unit_ids), default=0.04)
        with self._lock:
            self.requests.append(request)
            self.in_flight += 1
            self.maximum_in_flight = max(self.maximum_in_flight, self.in_flight)
            self.active_operations.add(request.operation)
            if {"translation", "glossary"} <= self.active_operations:
                self.glossary_translation_overlap = True
        try:
            time.sleep(delay)
            if request.operation == "review":
                content = {
                    "reviews": [
                        {
                            "id": unit["id"],
                            "decision": "keep",
                            "text": unit["current_translation"],
                            "issue_codes": [],
                        }
                        for unit in payload["units"]
                    ]
                }
            elif request.operation == "glossary":
                content = {
                    "resolutions": [
                        {
                            "candidate_id": candidate["id"],
                            "target_term": candidate["candidate_target"] or "Termo",
                            "status": "confirmed",
                            "reason": "Consistent project terminology.",
                        }
                        for candidate in payload["candidates"]
                    ]
                }
            else:
                translations = {
                    unit["id"]: "" if unit["id"] in self.failing_ids else unit["source"]
                    for unit in payload["units"]
                }
                content = {
                    "translations": translations,
                    "grammatical_genders": {
                        unit["id"]: "masculine"
                        for unit in payload["units"]
                        if unit["gender_required"]
                    },
                }
                if "terminology_decisions" in request.schema["properties"]:
                    content["terminology_decisions"] = []
            return ProviderResponse(json.dumps(content), "stop", "fake-response")
        finally:
            with self._lock:
                self.in_flight -= 1
                self.active_operations.discard(request.operation)


class PartialBlockingProvider:
    def __init__(self) -> None:
        self.request_count = 0
        self.second_request_started = threading.Event()
        self.release_second_request = threading.Event()

    def complete(self, request: ProviderRequest) -> ProviderResponse:
        self.request_count += 1
        payload = json.loads(request.messages[1]["content"])
        if self.request_count == 1:
            translations = {
                unit["id"]: unit["source"] if index == 0 else ""
                for index, unit in enumerate(payload["units"])
            }
        else:
            self.second_request_started.set()
            self.release_second_request.wait(2)
            translations = {unit["id"]: unit["source"] for unit in payload["units"]}
        return ProviderResponse(
            json.dumps(
                {
                    "translations": translations,
                    "grammatical_genders": {},
                }
            ),
            "stop",
            f"partial-{self.request_count}",
        )


def create_project(root: Path) -> tuple[SoulashFormatHandler, object]:
    source = root / "source"
    source.mkdir()
    (source / "messages.json").write_text(
        json.dumps(
            {
                "first": "Sword",
                "second": "Shield",
                "third": "Deal ::damage.",
            }
        ),
        encoding="utf-8",
    )
    (source / "language_metadata.json").write_text('{"id":"en","name":"English"}', encoding="utf-8")
    handler = SoulashFormatHandler()
    return handler, handler.load(source)


def settings(root: Path, **overrides: object) -> PipelineSettings:
    values: dict[str, object] = {
        "mode": "normal",
        "target_language": "pt-BR",
        "project_context": "test project",
        "model": "fake-model",
        "glossary_model": "fake-glossary",
        "backend_fingerprint": "fake-backend",
        "output_root": root / "PTBR",
        "state_root": root / ".state",
        "resume": True,
        "batch_size": 1,
        "maximum_batch_characters": 1_000,
        "retries": 0,
        "translation_concurrency": 2,
        "glossary_enabled": False,
        "glossary_worker_enabled": False,
        "wait_for_glossary": False,
    }
    values.update(overrides)
    return PipelineSettings(**values)


class PipelineTests(unittest.TestCase):
    def test_partial_valid_id_is_checkpointed_while_retry_is_still_running(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            handler, project = create_project(root)
            provider = PartialBlockingProvider()
            pipeline = LocalizationPipeline(
                handler=handler,
                translation_provider=provider,
                glossary_provider=provider,
            )
            holder: dict[str, object] = {}

            def run_pipeline() -> None:
                holder["result"] = pipeline.run(
                    project,
                    settings(
                        root,
                        batch_size=10,
                        retries=1,
                        translation_concurrency=1,
                    ),
                )

            thread = threading.Thread(target=run_pipeline)
            thread.start()
            self.assertTrue(provider.second_request_started.wait(1))
            checkpoint_path = root / ".state" / "checkpoints.sqlite3"
            checkpointed = 0
            deadline = time.monotonic() + 1
            while time.monotonic() < deadline:
                connection = sqlite3.connect(checkpoint_path)
                try:
                    checkpointed = int(
                        connection.execute("SELECT COUNT(*) FROM accepted_results").fetchone()[0]
                    )
                finally:
                    connection.close()
                if checkpointed == 1:
                    break
                time.sleep(0.02)

            self.assertEqual(checkpointed, 1)
            provider.release_second_request.set()
            thread.join(2)
            self.assertFalse(thread.is_alive())
            self.assertTrue(holder["result"].published)

    def test_concurrent_results_commit_in_order_and_publish_complete_output(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            handler, project = create_project(root)
            unit_ids = [unit.unit_id for unit in project.units]
            provider = PipelineFakeProvider(delays={unit_ids[0]: 0.08, unit_ids[1]: 0.01})
            events: list[dict[str, object]] = []
            pipeline = LocalizationPipeline(
                handler=handler,
                translation_provider=provider,
                glossary_provider=provider,
                progress=events.append,
            )

            result = pipeline.run(project, settings(root))

            self.assertTrue(result.published)
            self.assertEqual(result.accepted_units, 3)
            self.assertGreaterEqual(provider.maximum_in_flight, 2)
            committed = [event["batch"] for event in events if event["event"] == "batch_committed"]
            self.assertEqual(committed, [0, 1, 2])
            handler.validate_published(project, root / "PTBR")

    def test_failed_later_wave_preserves_checkpoints_and_resume_sends_only_pending(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            handler, project = create_project(root)
            failing_id = project.units[-1].unit_id
            failing_provider = PipelineFakeProvider(failing_ids={failing_id})
            first_pipeline = LocalizationPipeline(
                handler=handler,
                translation_provider=failing_provider,
                glossary_provider=failing_provider,
            )

            failed = first_pipeline.run(project, settings(root))

            self.assertFalse(failed.published)
            self.assertEqual(failed.accepted_units, 2)
            self.assertEqual(set(failed.failures), {failing_id})
            self.assertFalse((root / "PTBR").exists())

            resumed_provider = PipelineFakeProvider()
            resumed_pipeline = LocalizationPipeline(
                handler=handler,
                translation_provider=resumed_provider,
                glossary_provider=resumed_provider,
            )
            completed = resumed_pipeline.run(project, settings(root))

            sent_ids = {
                unit["id"]
                for request in resumed_provider.requests
                for unit in json.loads(request.messages[1]["content"])["units"]
            }
            self.assertTrue(completed.resumed)
            self.assertEqual(completed.reused_units, 2)
            self.assertEqual(sent_ids, {failing_id})
            self.assertTrue(completed.published)

    def test_review_uses_separate_generation_and_preserves_previous_output(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            handler, project = create_project(root)
            translation_provider = PipelineFakeProvider()
            LocalizationPipeline(
                handler=handler,
                translation_provider=translation_provider,
                glossary_provider=translation_provider,
            ).run(project, settings(root, resume=False))
            review_provider = PipelineFakeProvider()

            reviewed = LocalizationPipeline(
                handler=handler,
                translation_provider=review_provider,
                glossary_provider=review_provider,
            ).run(project, settings(root, mode="review", resume=False))

            self.assertTrue(reviewed.published)
            self.assertIsNotNone(reviewed.previous_output)
            self.assertTrue(reviewed.previous_output.is_dir())
            self.assertEqual(
                [request.operation for request in review_provider.requests],
                ["review", "review", "review"],
            )
            with CheckpointStore(root / ".state" / "checkpoints.sqlite3") as store:
                self.assertEqual(store.generation_count(), 2)

    def test_glossary_worker_overlaps_translation_without_blocking_publication(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            handler, project = create_project(root)
            state_root = root / ".state"
            with GlossaryStore(state_root / "glossary.sqlite3") as store:
                store.queue_task(
                    signal="manual",
                    source_term="Soul Gem",
                    candidate_target="Gema da Alma",
                    scope="items",
                    evidence_unit_id=project.units[0].unit_id,
                )
            provider = PipelineFakeProvider()

            result = LocalizationPipeline(
                handler=handler,
                translation_provider=provider,
                glossary_provider=provider,
            ).run(
                project,
                settings(
                    root,
                    glossary_enabled=True,
                    glossary_worker_enabled=True,
                ),
            )

            self.assertTrue(result.published)
            self.assertTrue(provider.glossary_translation_overlap)
            self.assertEqual(result.glossary_pending, 0)


if __name__ == "__main__":
    unittest.main()
