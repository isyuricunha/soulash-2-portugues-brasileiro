from __future__ import annotations

from localization.models import TranslationUnit
from localization.protection import protect_text


def make_unit(
    unit_id: str,
    text: str,
    *,
    gender_eligible: bool = False,
    context: str = "Soulash 2 test context",
) -> TranslationUnit:
    return TranslationUnit(
        unit_id=unit_id,
        relative_path="messages.json",
        pointer=(unit_id,),
        stable_path=unit_id,
        source_text=text,
        protected=protect_text(text),
        context=context,
        gender_eligible=gender_eligible,
    )
