from __future__ import annotations

import json
import unittest
from collections import deque

from localization.batching import AdaptiveBatcher, TranslationRecovery
from localization.errors import TransientProviderError
from localization.models import ProviderRequest, ProviderResponse
from tests.helpers import make_unit


class ScriptedProvider:
    def __init__(self, responses: list[str]) -> None:
        self.responses = deque(responses)
        self.requests: list[ProviderRequest] = []

    def complete(self, request: ProviderRequest) -> ProviderResponse:
        self.requests.append(request)
        return ProviderResponse(self.responses.popleft(), "stop", f"fake-{len(self.requests)}")


class TransientProvider:
    def __init__(self) -> None:
        self.requests: list[ProviderRequest] = []

    def complete(self, request: ProviderRequest) -> ProviderResponse:
        self.requests.append(request)
        raise TransientProviderError("temporary service failure")


def response(translations: dict[str, str]) -> str:
    return json.dumps(
        {
            "translations": translations,
            "grammatical_genders": {},
            "terminology_decisions": [],
        }
    )


class BatchingTests(unittest.TestCase):
    def test_adaptive_batching_considers_characters_tokens_and_complexity(self) -> None:
        units = [
            make_unit("u1", "Short"),
            make_unit("u2", "Deal ::damage [color=1,2,3,4]now[/color]."),
            make_unit("u3", "x" * 90),
        ]
        batcher = AdaptiveBatcher(
            maximum_units=3,
            maximum_characters=100,
            maximum_estimated_input_tokens=100,
        )

        batches = batcher.create_batches(units)

        self.assertEqual([len(batch.units) for batch in batches], [2, 1])
        self.assertGreater(batches[0].protected_token_count, 0)

    def test_partial_valid_response_retries_only_invalid_ids_with_feedback(self) -> None:
        units = (
            make_unit("u1", "Sword"),
            make_unit("u2", "Deal ::damage."),
            make_unit("u3", "Shield"),
        )
        provider = ScriptedProvider(
            [
                response({"u1": "Espada", "u2": "Causa dano."}),
                response({"u2": "Causa __KEEP_0__.", "u3": "Escudo"}),
            ]
        )
        recovery = TranslationRecovery(
            provider=provider,
            model="fake-model",
            project_context="test",
            retries=1,
            relevant_glossary=lambda _: (),
            allow_terminology_decisions=True,
            sleep=lambda _: None,
        )

        outcome = recovery.resolve(units)

        self.assertEqual(set(outcome.accepted), {"u1", "u2", "u3"})
        self.assertFalse(outcome.failures)
        self.assertEqual(outcome.request_count, 2)
        second_payload = json.loads(provider.requests[1].messages[1]["content"])
        self.assertEqual({item["id"] for item in second_payload["units"]}, {"u2", "u3"})
        self.assertIn("previous response failed", second_payload["corrective_feedback"])

    def test_deterministic_failure_splits_while_sharing_root_budget(self) -> None:
        units = (make_unit("u1", "Sword"), make_unit("u2", "Shield"))
        provider = ScriptedProvider(
            [
                "not-json",
                response({"u1": "Espada"}),
                response({"u2": "Escudo"}),
            ]
        )
        recovery = TranslationRecovery(
            provider=provider,
            model="fake-model",
            project_context="test",
            retries=0,
            relevant_glossary=lambda _: (),
            allow_terminology_decisions=True,
            sleep=lambda _: None,
        )

        outcome = recovery.resolve(units)

        self.assertEqual(set(outcome.accepted), {"u1", "u2"})
        self.assertEqual(outcome.request_count, 3)

    def test_transient_failure_retries_same_batch_without_splitting(self) -> None:
        units = (make_unit("u1", "Sword"), make_unit("u2", "Shield"))
        provider = TransientProvider()
        recovery = TranslationRecovery(
            provider=provider,
            model="fake-model",
            project_context="test",
            retries=1,
            relevant_glossary=lambda _: (),
            allow_terminology_decisions=True,
            sleep=lambda _: None,
        )

        outcome = recovery.resolve(units)

        self.assertEqual(len(provider.requests), 2)
        requested = [
            {item["id"] for item in json.loads(request.messages[1]["content"])["units"]}
            for request in provider.requests
        ]
        self.assertEqual(requested, [{"u1", "u2"}, {"u1", "u2"}])
        self.assertEqual(set(outcome.failures), {"u1", "u2"})


if __name__ == "__main__":
    unittest.main()
