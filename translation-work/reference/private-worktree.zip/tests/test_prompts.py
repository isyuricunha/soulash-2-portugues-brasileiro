from __future__ import annotations

import json
import unittest
from pathlib import Path

from localization.cli import build_parser
from localization.config import RunConfig
from localization.game_context import DEFAULT_PROJECT_CONTEXT, SOULASH_2_CANONICAL_CONTEXT
from localization.prompts import (
    SYSTEM_PROMPT,
    TRANSLATION_POLICY_REVISION,
    review_messages,
    translation_messages,
)
from tests.helpers import make_unit


class PromptTests(unittest.TestCase):
    def test_system_prompt_contains_canonical_game_and_register_context(self) -> None:
        required_context = (
            "where the gods have perished",
            "procedurally generated open world",
            "trade routes",
            "character lifecycles",
            "founding a family",
            "turn-based combat",
            "Do not invent lore",
            "medieval archaism",
            "Procedural fragments",
        )

        self.assertIn(SOULASH_2_CANONICAL_CONTEXT, SYSTEM_PROMPT)
        for text in required_context:
            with self.subTest(text=text):
                self.assertIn(text, SYSTEM_PROMPT)

    def test_translation_and_review_keep_runtime_context_supplementary(self) -> None:
        unit = make_unit("sword-name", "Sword", context="items.json / sword / name")
        translation = translation_messages(
            (unit,),
            project_context="This file contains item names.",
            glossary=(),
        )
        review = review_messages(
            (unit,),
            {unit.unit_id: "Espada"},
            project_context="This file contains item names.",
        )
        translation_payload = json.loads(translation[1]["content"])
        review_payload = json.loads(review[1]["content"])

        self.assertEqual(translation[0]["content"], SYSTEM_PROMPT)
        self.assertEqual(review[0]["content"], SYSTEM_PROMPT)
        self.assertEqual(translation_payload["project_context"], "This file contains item names.")
        self.assertEqual(review_payload["project_context"], "This file contains item names.")
        self.assertEqual(translation_payload["units"][0]["context"], "items.json / sword / name")
        self.assertEqual(review_payload["units"][0]["context"], "items.json / sword / name")

    def test_cli_and_run_config_share_the_same_default_context(self) -> None:
        parser_context = build_parser().parse_args([]).project_context
        run_context = RunConfig(
            repository_root=Path("."),
            input_root=Path("EN"),
            output_root=Path("PTBR"),
            state_root=Path(".localization-state"),
        ).project_context

        self.assertEqual(parser_context, DEFAULT_PROJECT_CONTEXT)
        self.assertEqual(run_context, DEFAULT_PROJECT_CONTEXT)
        self.assertEqual(TRANSLATION_POLICY_REVISION, "ptbr-policy-v2")


if __name__ == "__main__":
    unittest.main()
