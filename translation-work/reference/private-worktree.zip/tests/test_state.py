from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from localization.checkpoint import CheckpointStore
from localization.errors import ValidationError
from localization.glossary import GlossaryStore
from localization.models import AcceptedTranslation, GenerationSpec
from tests.helpers import make_unit


def generation_spec(*, mode: str = "normal", manifest: str = "manifest-a") -> GenerationSpec:
    return GenerationSpec(
        mode=mode,
        source_manifest=manifest,
        target_language="pt-BR",
        project_profile_fingerprint="profile-a",
        policy_revision="policy-a",
        protection_revision="protection-a",
        backend_fingerprint="backend-a",
    )


class CheckpointTests(unittest.TestCase):
    def test_resume_reuses_only_compatible_generation_and_no_resume_still_persists(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "checkpoints.sqlite3"
            with CheckpointStore(path) as store:
                first_id, resumed = store.open_generation(generation_spec(), resume=True)
                resumed_id, resumed = store.open_generation(generation_spec(), resume=True)
                fresh_id, fresh_resumed = store.open_generation(generation_spec(), resume=False)
                review_id, review_resumed = store.open_generation(
                    generation_spec(mode="review"), resume=True
                )

                self.assertFalse(first_id == fresh_id)
                self.assertTrue(resumed)
                self.assertEqual(first_id, resumed_id)
                self.assertFalse(fresh_resumed)
                self.assertFalse(review_resumed)
                self.assertNotEqual(review_id, first_id)
                self.assertEqual(store.generation_count(), 3)

    def test_changed_protected_source_invalidates_only_affected_unit(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "checkpoints.sqlite3"
            original = make_unit("u1", "Deal ::damage.")
            stable = make_unit("u2", "Shield")
            accepted = {
                "u1": AcceptedTranslation("u1", "Cause __KEEP_0__.", "Cause ::damage."),
                "u2": AcceptedTranslation("u2", "Escudo", "Escudo"),
            }
            with CheckpointStore(path) as store:
                generation_id, _ = store.open_generation(generation_spec(), resume=False)
                store.commit_accepted(generation_id, {"u1": original, "u2": stable}, accepted)
                changed = make_unit("u1", "Deal ::amount.")

                loaded = store.load_compatible(generation_id, [changed, stable])

                self.assertEqual(set(loaded), {"u2"})

    def test_invalid_restored_checkpoint_is_not_reused(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "checkpoints.sqlite3"
            invalid = make_unit("u1", "Strength +2, Willpower +2")
            stable = make_unit("u2", "Shield")
            inconsistent = make_unit("u3", "Sword")
            accepted = {
                "u1": AcceptedTranslation("u1", "Força __KEEP_0____KEEP_1__", "Força +2+2"),
                "u2": AcceptedTranslation("u2", "Escudo", "Escudo"),
                "u3": AcceptedTranslation("u3", "Espada", "Lâmina"),
            }
            with CheckpointStore(path) as store:
                generation_id, _ = store.open_generation(generation_spec(), resume=False)
                store.commit_accepted(
                    generation_id,
                    {"u1": invalid, "u2": stable, "u3": inconsistent},
                    accepted,
                )

                loaded = store.load_compatible(generation_id, [invalid, stable, inconsistent])

                self.assertEqual(set(loaded), {"u2"})


class GlossaryTests(unittest.TestCase):
    def test_locked_precedence_relevant_retrieval_and_selective_task_routing(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "glossary.sqlite3"
            with GlossaryStore(path) as store:
                store.upsert_entry(
                    source_term="Iron Sword",
                    target_term="Espada de Ferro",
                    scope="global",
                    status="locked",
                    confidence=1.0,
                    aliases=("iron blade",),
                )
                store.upsert_entry(
                    source_term="Mana",
                    target_term="Mana",
                    scope="magic",
                    status="confirmed",
                    confidence=0.9,
                )

                relevant = store.relevant((make_unit("u1", "Equip the iron blade."),))
                route, task_id = store.queue_task(
                    signal="translated_text_differs",
                    source_term="ordinary",
                    candidate_target="comum",
                    scope="global",
                    evidence_unit_id="u1",
                )
                queued_route, queued_id = store.queue_task(
                    signal="terminology_decision",
                    source_term="Soul Gem",
                    candidate_target="Gema da Alma",
                    scope="items",
                    evidence_unit_id="u1",
                )

                self.assertEqual([entry.source_term for entry in relevant], ["Iron Sword"])
                self.assertEqual((route, task_id), ("skipped_no_signal", None))
                self.assertEqual(queued_route, "queued")
                self.assertIsNotNone(queued_id)
                self.assertEqual(len(store.pending_tasks(limit=10)), 1)
                with self.assertRaises(ValidationError):
                    store.upsert_entry(
                        source_term="Iron Sword",
                        target_term="Espada Férrea",
                        scope="global",
                        status="provisional",
                        confidence=0.5,
                    )


if __name__ == "__main__":
    unittest.main()
