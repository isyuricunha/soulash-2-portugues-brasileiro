from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from localization.errors import FormatError, ValidationError
from localization.formats.soulash import SoulashFormatHandler
from localization.models import AcceptedTranslation


class SoulashFormatTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary_directory.name)
        self.source = self.root / "source"
        (self.source / "entities").mkdir(parents=True)
        (self.source / "npc" / "names").mkdir(parents=True)
        (self.source / "entities" / "108_Hatchet.json").write_text(
            json.dumps(
                {
                    "id": "108",
                    "name": "Hatchet",
                    "description": "Deal ::damage damage.",
                    "resource": {"affix": "Sharp", "quality": 1},
                    "value": 400,
                }
            ),
            encoding="utf-8",
        )
        (self.source / "npc" / "names" / "human_male.txt").write_bytes(b"Arthur\r\nEdward\r\n")
        (self.source / "language_metadata.json").write_text(
            '{"id":"en","name":"English"}', encoding="utf-8"
        )
        self.handler = SoulashFormatHandler()

    def tearDown(self) -> None:
        self.temporary_directory.cleanup()

    def test_extracts_only_player_facing_fields_and_adds_feminine_affix_unit(self) -> None:
        project = self.handler.load(self.source)

        texts = [unit.source_text for unit in project.units]
        self.assertEqual(texts.count("Hatchet"), 1)
        self.assertEqual(texts.count("Deal ::damage damage."), 1)
        self.assertEqual(texts.count("Sharp"), 2)
        self.assertNotIn("108", texts)
        self.assertNotIn("Arthur", texts)
        self.assertTrue(any(unit.gender_eligible for unit in project.units))
        self.assertTrue(any(unit.synthetic for unit in project.units))

    def test_reconstruction_preserves_structure_txt_and_adds_gender_metadata(self) -> None:
        project = self.handler.load(self.source)
        accepted: dict[str, AcceptedTranslation] = {}
        for unit in project.units:
            text = unit.protected.text
            restored = unit.source_text
            gender = "feminine" if unit.gender_eligible else None
            accepted[unit.unit_id] = AcceptedTranslation(
                unit_id=unit.unit_id,
                protected_text=text,
                restored_text=restored,
                grammatical_gender=gender,
            )
        destination = self.root / "PTBR"

        result = self.handler.reconstruct(project, accepted, destination)

        rebuilt = json.loads(
            (destination / "translations" / "ptbr" / "entities" / "108_Hatchet.json").read_text(
                encoding="utf-8"
            )
        )
        self.assertEqual(rebuilt["id"], "108")
        self.assertEqual(rebuilt["value"], 400)
        self.assertTrue(rebuilt["feminine_form"])
        self.assertEqual(rebuilt["resource"]["feminine_affix"], "Sharp")
        self.assertEqual(
            (
                destination / "translations" / "ptbr" / "npc" / "names" / "human_male.txt"
            ).read_bytes(),
            b"Arthur\r\nEdward\r\n",
        )
        self.assertEqual(result.unit_count, len(project.units))
        self.handler.validate_published(project, destination)
        (destination / "mod.json").write_text("{}", encoding="utf-8")
        with self.assertRaises(ValidationError):
            self.handler.validate_published(project, destination)

    def test_partial_reconstruction_is_rejected(self) -> None:
        project = self.handler.load(self.source)

        with self.assertRaises(ValidationError):
            self.handler.reconstruct(project, {}, self.root / "PTBR")

    def test_duplicate_json_keys_are_rejected(self) -> None:
        (self.source / "messages.json").write_text('{"main":1,"main":2}', encoding="utf-8")

        with self.assertRaises(FormatError):
            self.handler.load(self.source)

    def test_source_refresh_is_guarded_and_hashes_the_snapshot(self) -> None:
        snapshot = self.root / "EN"

        manifest = self.handler.refresh_source(self.source, snapshot)

        self.assertEqual(manifest["units"], 4)
        self.assertTrue((snapshot / "source-manifest.json").is_file())
        with self.assertRaises(ValidationError):
            self.handler.refresh_source(self.source, snapshot)

    def test_duplicate_declared_list_ids_receive_stable_occurrence_segments(self) -> None:
        (self.source / "conversations.json").write_text(
            json.dumps(
                {
                    "conversations": [
                        {"id": "duplicate", "text": "First version"},
                        {"id": "duplicate", "text": "Second version"},
                    ]
                }
            ),
            encoding="utf-8",
        )

        project = self.handler.load(self.source)
        duplicate_units = [
            unit for unit in project.units if unit.relative_path == "conversations.json"
        ]

        self.assertEqual(len(duplicate_units), 2)
        self.assertEqual(len({unit.unit_id for unit in duplicate_units}), 2)
        self.assertEqual(
            [unit.stable_path for unit in duplicate_units],
            [
                "conversations/@id=duplicate#0/text",
                "conversations/@id=duplicate#1/text",
            ],
        )

    def test_internal_dialogue_and_location_names_are_not_translated(self) -> None:
        (self.source / "dialogues.json").write_text(
            '[{"id":1,"name":"Human noble fight","monologue":["Attack!"]}]',
            encoding="utf-8",
        )
        (self.source / "locations.json").write_text(
            '[{"id":1,"name":"Forest Cave","internal_name":"Bat Cave"}]',
            encoding="utf-8",
        )

        project = self.handler.load(self.source)
        texts = {unit.source_text for unit in project.units}

        self.assertIn("Attack!", texts)
        self.assertIn("Forest Cave", texts)
        self.assertNotIn("Human noble fight", texts)
        self.assertNotIn("Bat Cave", texts)


if __name__ == "__main__":
    unittest.main()
