from __future__ import annotations

import json
import threading
import unittest
from unittest.mock import patch

from localization.config import ProviderConfig
from localization.errors import OutputBudgetError, ProviderContractError
from localization.models import ProviderRequest
from localization.provider import OpenAICompatibleProvider, ProviderCapacity


class FakeHttpResponse:
    def __init__(self, payload: dict[str, object]) -> None:
        self.raw = json.dumps(payload).encode("utf-8")

    def __enter__(self) -> FakeHttpResponse:
        return self

    def __exit__(self, *_: object) -> None:
        return None

    def read(self, _: int) -> bytes:
        return self.raw


class ProviderTests(unittest.TestCase):
    @staticmethod
    def _provider() -> OpenAICompatibleProvider:
        return OpenAICompatibleProvider(
            ProviderConfig(
                api_key="secret",
                base_url="https://gateway.example/v1",
                translation_model="vendor/model",
                glossary_model="vendor/model",
            )
        )

    @staticmethod
    def _request() -> ProviderRequest:
        return ProviderRequest(
            operation="translation",
            schema_name="translation_contract",
            schema={"type": "object", "additionalProperties": False},
            messages=({"role": "user", "content": "test"},),
            model="vendor/model",
        )

    def test_generic_adapter_sends_real_strict_schema_without_unverified_fields(self) -> None:
        config = ProviderConfig(
            api_key="secret",
            base_url="https://gateway.example/v1",
            translation_model="vendor/model",
            glossary_model="vendor/model",
        )
        provider = OpenAICompatibleProvider(config)
        request = ProviderRequest(
            operation="translation",
            schema_name="translation_contract",
            schema={"type": "object", "additionalProperties": False},
            messages=({"role": "user", "content": "test"},),
            model="vendor/model",
        )
        captured: dict[str, object] = {}

        def fake_urlopen(http_request: object, timeout: float) -> FakeHttpResponse:
            captured["request"] = http_request
            captured["timeout"] = timeout
            return FakeHttpResponse(
                {
                    "id": "response-1",
                    "choices": [
                        {
                            "message": {"content": '{"translations":{}}'},
                            "finish_reason": "stop",
                        }
                    ],
                }
            )

        with patch("urllib.request.urlopen", fake_urlopen):
            response = provider.complete(request)

        http_request = captured["request"]
        payload = json.loads(http_request.data.decode("utf-8"))
        self.assertEqual(http_request.full_url, "https://gateway.example/v1/chat/completions")
        self.assertEqual(payload["response_format"]["type"], "json_schema")
        self.assertTrue(payload["response_format"]["json_schema"]["strict"])
        self.assertEqual(payload["response_format"]["json_schema"]["schema"], request.schema)
        self.assertNotIn("reasoning_effort", payload)
        self.assertNotIn("max_tokens", payload)
        self.assertEqual(response.response_id, "response-1")

    def test_empty_final_message_and_completion_exhaustion_are_failures(self) -> None:
        provider = self._provider()
        request = self._request()
        cases = (
            (
                {"choices": [{"message": {"content": ""}, "finish_reason": "stop"}]},
                ProviderContractError,
            ),
            (
                {"choices": [{"message": {"content": "{}"}, "finish_reason": "length"}]},
                OutputBudgetError,
            ),
        )
        for envelope, expected_error in cases:

            def fake_urlopen(
                *_args: object, payload: dict[str, object] = envelope, **_kwargs: object
            ) -> FakeHttpResponse:
                return FakeHttpResponse(payload)

            with (
                self.subTest(expected_error=expected_error),
                patch("urllib.request.urlopen", fake_urlopen),
                self.assertRaises(expected_error),
            ):
                provider.complete(request)

    def test_capacity_reserves_glossary_to_one_slot_and_never_exceeds_total(self) -> None:
        capacity = ProviderCapacity(maximum=5, minimum_translation_slots=4)
        first_acquired = threading.Event()
        release_first = threading.Event()
        second_acquired = threading.Event()

        def first_glossary() -> None:
            with capacity.slot("glossary"):
                first_acquired.set()
                release_first.wait(2)

        def second_glossary() -> None:
            with capacity.slot("glossary"):
                second_acquired.set()

        first = threading.Thread(target=first_glossary)
        second = threading.Thread(target=second_glossary)
        first.start()
        self.assertTrue(first_acquired.wait(1))
        second.start()
        self.assertFalse(second_acquired.wait(0.05))
        with capacity.slot("main"):
            self.assertEqual(capacity.in_flight, 2)
        release_first.set()
        first.join(1)
        second.join(1)
        self.assertTrue(second_acquired.is_set())
        self.assertLessEqual(capacity.in_flight, 5)

    def test_waiting_main_request_has_priority_over_waiting_glossary(self) -> None:
        capacity = ProviderCapacity(maximum=1, minimum_translation_slots=0)
        holder_acquired = threading.Event()
        release_holder = threading.Event()
        acquisition_order: list[str] = []

        def holder() -> None:
            with capacity.slot("glossary"):
                holder_acquired.set()
                release_holder.wait(2)

        def waiter(kind: str) -> None:
            with capacity.slot(kind):
                acquisition_order.append(kind)

        holder_thread = threading.Thread(target=holder)
        glossary_thread = threading.Thread(target=waiter, args=("glossary",))
        main_thread = threading.Thread(target=waiter, args=("main",))
        holder_thread.start()
        self.assertTrue(holder_acquired.wait(1))
        glossary_thread.start()
        main_thread.start()
        release_holder.set()
        holder_thread.join(1)
        glossary_thread.join(1)
        main_thread.join(1)

        self.assertEqual(acquisition_order, ["main", "glossary"])


if __name__ == "__main__":
    unittest.main()
