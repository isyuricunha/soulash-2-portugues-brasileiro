"""Behavioral tests for the localization toolkit."""
