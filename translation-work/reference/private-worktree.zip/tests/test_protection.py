from __future__ import annotations

import unittest

from localization.errors import ProtectionError
from localization.protection import protect_text, restore_text, validate_protected_translation


class ProtectionTests(unittest.TestCase):
    def test_independent_tokens_may_be_reordered(self) -> None:
        source = protect_text("Deal ::damage {} damage.")
        candidate = "Cause __KEEP_1__ de dano com __KEEP_0__."

        validate_protected_translation(source, candidate)

        self.assertEqual(restore_text(source, candidate), "Cause {} de dano com ::damage.")

    def test_missing_duplicated_changed_and_invented_tokens_are_rejected(self) -> None:
        source = protect_text("Deal ::damage {} damage.")

        for candidate in (
            "Cause __KEEP_0__ de dano.",
            "Cause __KEEP_0__ __KEEP_0__ __KEEP_1__ de dano.",
            "Cause __KEEP_0__ __KEEP_9__ de dano.",
            "Cause __KEEP_0__ __KEEP_1__ ::invented de dano.",
        ):
            with self.subTest(candidate=candidate), self.assertRaises(ProtectionError):
                validate_protected_translation(source, candidate)

    def test_color_markup_must_remain_balanced_and_nested(self) -> None:
        source = protect_text("[color=1,2,3,4]Outer [color=5,6,7,8]inner[/color][/color]")
        invalid = "__KEEP_0__Fora __KEEP_2__dentro__KEEP_1____KEEP_3__"

        with self.assertRaises(ProtectionError):
            validate_protected_translation(source, invalid)

    def test_line_break_numbers_printf_and_control_glyphs_are_preserved(self) -> None:
        source = protect_text("Move 0, x10, or roll 1d10 at ::chance%\nPress >> or use %s.")

        restored = restore_text(source, source.text)

        self.assertEqual(
            restored,
            "Move 0, x10, or roll 1d10 at ::chance%\nPress >> or use %s.",
        )

    def test_percentage_followed_by_plain_text_is_not_misread_as_printf(self) -> None:
        source = protect_text("Increases damage by 0.2% per point.")

        self.assertEqual([token.raw_value for token in source.tokens], ["0.2%"])
        self.assertNotIn("per", source.tokens[0].raw_value)

    def test_malformed_source_markup_fails_loudly(self) -> None:
        with self.assertRaises(ProtectionError):
            protect_text("[color=1,2,3,4]broken")

    def test_invented_number_line_break_and_control_glyph_are_rejected(self) -> None:
        source = protect_text("Safe text")
        for candidate in ("Texto 5", "Texto\nextra", "Texto >>"):
            with self.subTest(candidate=candidate), self.assertRaises(ProtectionError):
                validate_protected_translation(source, candidate)

    def test_restoration_rejects_tokens_that_coalesce_into_different_syntax(self) -> None:
        cases = (
            ("Strength +2, Willpower +2", "Força __KEEP_0____KEEP_1__"),
            ("First\nSecond\nThird", "Primeiro__KEEP_0____KEEP_1__Terceiro"),
        )

        for source_text, candidate in cases:
            with self.subTest(source_text=source_text), self.assertRaises(ProtectionError):
                restore_text(protect_text(source_text), candidate)


if __name__ == "__main__":
    unittest.main()
