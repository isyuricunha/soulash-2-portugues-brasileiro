# Project TODO

## Milestone 1: repository foundation and Soulash format

- [x] Inspect the installed runtime, current source data, and old project failure modes.
- [x] Define the applicability matrix from repository evidence.
- [x] Add typed project models and portable configuration primitives.
- [x] Implement Soulash 2 source discovery, extraction, reconstruction, and validation.
- [x] Implement repository-specific protected-token handling.
- [x] Validate Milestone 1 with formatting, lint, compilation, and unit tests.

## Milestone 2: provider execution and durable state

- [x] Implement strict operation-specific JSON Schemas and local response validation.
- [x] Implement the generic OpenAI-compatible HTTP adapter without unsupported model fields.
- [x] Implement adaptive batching, bounded retries, partial recovery, and safe splitting.
- [x] Implement global provider capacity with translation priority.
- [x] Implement SQLite/WAL generations, checkpoints, resume, and no-resume semantics.
- [x] Implement the project-local glossary and selective worker routing.

## Milestone 3: end-to-end modes and publication

- [x] Implement normal, review, and remake flows.
- [x] Implement deterministic concurrent orchestration and incremental checkpoint commits.
- [x] Implement staging, complete-file validation, manifest generation, and guarded promotion.
- [x] Implement the documented CLI and truthful progress reporting.

## Milestone 4: real-source and release validation

- [x] Refresh `EN` from the installed Soulash 2 source through the toolkit.
- [x] Run self-test, dry-run, and validate-only against the real source snapshot.
- [x] Verify source hashes and confirm the installed game remains unchanged.
- [x] Review the final diff, documentation, and remaining runtime limitations.

## Milestone 5: canonical game context

- [x] Research the official Soulash 2 setting, systems, and player roles.
- [x] Add the canonical game profile to translation and review system messages.
- [x] Define register rules for UI, mechanics, dialogue, and procedural narrative.
- [x] Validate prompt composition, checkpoint revisioning, formatting, lint, compilation, and tests.

## Milestone 6: conservative default batches

- [x] Reduce the default batch ceiling to 10 units and 2,000 unit characters.
- [x] Expose the effective default limits in CLI help and documentation.
- [x] Validate CLI defaults, real-source batching, formatting, lint, compilation, and tests.

## Milestone 7: live progress ETA

- [x] Render interactive translation progress in place on one terminal line.
- [x] Report percentage, accepted units, throughput, and an `HH:MM:SS` ETA.
- [x] Preserve verbose JSON logs and clean redirected output behavior.
- [x] Validate progress rendering, failure cleanup, formatting, lint, compilation, and tests.

## Milestone 8: restored technical-token validation

- [x] Reproduce and identify technical tokens that change meaning after restoration.
- [x] Reject non-round-trippable provider results before checkpoint acceptance.
- [x] Exclude only incompatible legacy results when resuming a generation.
- [x] Cover numeric, line-break, schema, and checkpoint recovery scenarios.
- [x] Resume the live generation, publish PTBR, and pass the complete offline validation.
