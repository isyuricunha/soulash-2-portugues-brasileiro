from __future__ import annotations

import hashlib
import json
import queue
import re
import time
from collections.abc import Callable
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from localization.batching import AdaptiveBatcher, ReviewRecovery, TranslationRecovery
from localization.checkpoint import CheckpointStore
from localization.errors import ProviderError, ValidationError
from localization.formats.soulash import SoulashFormatHandler
from localization.glossary import GlossaryStore, GlossaryWorker
from localization.models import (
    AcceptedTranslation,
    BatchOutcome,
    GenerationSpec,
    GlossaryEntry,
    PipelineResult,
    SourceProject,
    TranslationBatch,
    TranslationUnit,
)
from localization.prompts import TRANSLATION_POLICY_REVISION
from localization.protection import PROTECTION_REVISION
from localization.provider import Provider
from localization.publication import PublicationManager

ProgressCallback = Callable[[dict[str, Any]], None]


@dataclass(frozen=True, slots=True)
class PipelineSettings:
    mode: str
    target_language: str
    project_context: str
    model: str
    glossary_model: str
    backend_fingerprint: str
    output_root: Path
    state_root: Path
    resume: bool
    batch_size: int
    maximum_batch_characters: int
    retries: int
    translation_concurrency: int
    glossary_enabled: bool
    glossary_worker_enabled: bool
    wait_for_glossary: bool

    def validate(self) -> None:
        if self.mode not in {"normal", "review", "remake"}:
            raise ValidationError(f"Unsupported pipeline mode: {self.mode}")
        if self.translation_concurrency < 1:
            raise ValidationError("Translation concurrency must be positive")


class LocalizationPipeline:
    def __init__(
        self,
        *,
        handler: SoulashFormatHandler,
        translation_provider: Provider,
        glossary_provider: Provider,
        progress: ProgressCallback | None = None,
    ) -> None:
        self.handler = handler
        self.translation_provider = translation_provider
        self.glossary_provider = glossary_provider
        self.progress = progress or (lambda _: None)

    def run(self, project: SourceProject, settings: PipelineSettings) -> PipelineResult:
        settings.validate()
        settings.state_root.mkdir(parents=True, exist_ok=True)
        checkpoint_path = settings.state_root / "checkpoints.sqlite3"
        glossary_path = settings.state_root / "glossary.sqlite3"
        units_by_id = {unit.unit_id: unit for unit in project.units}
        profile_fingerprint = hashlib.sha256(
            json.dumps(
                {
                    "target": settings.target_language,
                    "context": settings.project_context,
                },
                ensure_ascii=False,
                sort_keys=True,
            ).encode("utf-8")
        ).hexdigest()

        with CheckpointStore(checkpoint_path) as checkpoints:
            base_generation_id: int | None = None
            base_current: dict[str, AcceptedTranslation] = {}
            if settings.mode == "review":
                base_generation_id = checkpoints.latest_complete_generation(
                    source_manifest=project.manifest_hash,
                    target_language=settings.target_language,
                )
                if base_generation_id is None:
                    raise ValidationError("Review requires a complete compatible base generation")
                base_current = checkpoints.load_compatible(base_generation_id, project.units)
                if len(base_current) != len(project.units):
                    raise ValidationError("Review base generation is incomplete or stale")
            specification = GenerationSpec(
                mode=settings.mode,
                source_manifest=project.manifest_hash,
                target_language=settings.target_language,
                project_profile_fingerprint=profile_fingerprint,
                policy_revision=TRANSLATION_POLICY_REVISION,
                protection_revision=PROTECTION_REVISION,
                backend_fingerprint=settings.backend_fingerprint,
                base_generation_id=base_generation_id,
                staging_path=str(settings.output_root.parent / ".staging"),
            )
            generation_id, resumed = checkpoints.open_generation(
                specification, resume=settings.resume
            )
            accepted = checkpoints.load_compatible(generation_id, project.units)
            pending_units = [unit for unit in project.units if unit.unit_id not in accepted]
            result = PipelineResult(
                mode=settings.mode,
                generation_id=generation_id,
                resumed=resumed,
                selected_units=len(project.units),
                reused_units=len(accepted),
                accepted_units=len(accepted),
            )
            self.progress(
                {
                    "event": "generation_started",
                    "mode": settings.mode,
                    "generation_id": generation_id,
                    "selected": len(project.units),
                    "reused": len(accepted),
                    "pending": len(pending_units),
                }
            )
            batcher = AdaptiveBatcher(
                maximum_units=settings.batch_size,
                maximum_characters=settings.maximum_batch_characters,
            )
            batches = batcher.create_batches(pending_units)
            glossary_store = GlossaryStore(glossary_path) if settings.glossary_enabled else None
            try:
                if len(accepted) == len(project.units) and settings.output_root.exists():
                    self.handler.validate_published(project, settings.output_root)
                    checkpoints.set_status(generation_id, "published")
                    result.published = True
                    result.output_root = settings.output_root
                    result.glossary_pending = self._pending_count(glossary_store)
                    self.progress(
                        {
                            "event": "publication_reused",
                            "generation_id": generation_id,
                            "accepted": len(accepted),
                            "output": str(settings.output_root),
                        }
                    )
                    return result
                failures = self._run_batches(
                    batches=batches,
                    project=project,
                    settings=settings,
                    base_current=base_current,
                    checkpoints=checkpoints,
                    generation_id=generation_id,
                    units_by_id=units_by_id,
                    accepted=accepted,
                    glossary_store=glossary_store,
                    glossary_path=glossary_path,
                )
                result.accepted_units = len(accepted)
                result.failures = failures
                if failures:
                    checkpoints.set_status(generation_id, "failed")
                    result.glossary_pending = self._pending_count(glossary_store)
                    return result
                if len(accepted) != len(project.units):
                    raise ValidationError("Pipeline ended without every required translation unit")
                checkpoints.set_status(generation_id, "complete")
                publication, backup = PublicationManager(self.handler).publish(
                    project, accepted, settings.output_root
                )
                checkpoints.set_status(generation_id, "published")
                result.published = True
                result.output_root = publication.root
                result.previous_output = backup
                if settings.wait_for_glossary and glossary_store is not None:
                    self._drain_glossary(glossary_path, settings)
                result.glossary_pending = self._pending_count(glossary_store)
                self.progress(
                    {
                        "event": "published",
                        "generation_id": generation_id,
                        "accepted": len(accepted),
                        "output": str(settings.output_root),
                        "previous_output": str(backup) if backup else None,
                        "glossary_pending": result.glossary_pending,
                    }
                )
                return result
            finally:
                if glossary_store is not None:
                    glossary_store.close()

    def _run_batches(
        self,
        *,
        batches: list[TranslationBatch],
        project: SourceProject,
        settings: PipelineSettings,
        base_current: dict[str, AcceptedTranslation],
        checkpoints: CheckpointStore,
        generation_id: int,
        units_by_id: dict[str, TranslationUnit],
        accepted: dict[str, AcceptedTranslation],
        glossary_store: GlossaryStore | None,
        glossary_path: Path,
    ) -> dict[str, str]:
        failures: dict[str, str] = {}
        worker_future: Future[int] | None = None
        run_started = time.monotonic()
        accepted_at_start = len(accepted)
        with (
            ThreadPoolExecutor(
                max_workers=settings.translation_concurrency
            ) as translation_executor,
            ThreadPoolExecutor(max_workers=1) as glossary_executor,
        ):
            for wave_index, wave_start in enumerate(
                range(0, len(batches), settings.translation_concurrency), 1
            ):
                wave = batches[wave_start : wave_start + settings.translation_concurrency]
                if worker_future is not None and worker_future.done():
                    self._collect_worker_result(worker_future)
                    worker_future = None
                if (
                    settings.glossary_worker_enabled
                    and glossary_store is not None
                    and self._pending_count(glossary_store) > 0
                    and worker_future is None
                ):
                    worker_future = glossary_executor.submit(
                        self._run_glossary_once, glossary_path, settings
                    )
                snapshots = {
                    batch.batch_id: tuple(glossary_store.relevant(batch.units))
                    if glossary_store is not None
                    else ()
                    for batch in wave
                }
                partial_queue: queue.Queue[tuple[int, dict[str, AcceptedTranslation]]] = (
                    queue.Queue()
                )
                futures = {
                    translation_executor.submit(
                        self._execute_batch,
                        batch,
                        settings,
                        base_current,
                        snapshots[batch.batch_id],
                        lambda items, batch_id=batch.batch_id, event_queue=partial_queue: (
                            event_queue.put((batch_id, items))
                        ),
                    ): batch
                    for batch in wave
                }
                ready: dict[int, BatchOutcome] = {}
                partial_by_batch: dict[int, dict[str, AcceptedTranslation]] = {}
                next_batch_id = wave[0].batch_id if wave else 0
                pending_futures = set(futures)
                while pending_futures:
                    done, pending_futures = wait(
                        pending_futures,
                        timeout=0.05,
                        return_when=FIRST_COMPLETED,
                    )
                    for future in done:
                        batch = futures[future]
                        ready[batch.batch_id] = future.result()
                    while True:
                        try:
                            batch_id, partial = partial_queue.get_nowait()
                        except queue.Empty:
                            break
                        partial_by_batch.setdefault(batch_id, {}).update(partial)
                    while True:
                        partial = partial_by_batch.pop(next_batch_id, {})
                        fresh_partial = {
                            unit_id: item
                            for unit_id, item in partial.items()
                            if unit_id not in accepted
                        }
                        if fresh_partial:
                            checkpoints.commit_accepted(generation_id, units_by_id, fresh_partial)
                            accepted.update(fresh_partial)
                            self.progress(
                                {
                                    "event": "partial_checkpoint_committed",
                                    "wave": wave_index,
                                    "batch": next_batch_id,
                                    "accepted": len(fresh_partial),
                                    "checkpoint_total": len(accepted),
                                }
                            )
                        if next_batch_id not in ready:
                            break
                        outcome = ready.pop(next_batch_id)
                        batch_for_commit = batches[next_batch_id]
                        fresh_final = {
                            unit_id: item
                            for unit_id, item in outcome.accepted.items()
                            if unit_id not in accepted
                        }
                        if fresh_final:
                            checkpoints.commit_accepted(generation_id, units_by_id, fresh_final)
                            accepted.update(fresh_final)
                        failures.update(outcome.failures)
                        if glossary_store is not None:
                            self._route_terminology_decisions(
                                glossary_store,
                                outcome.terminology_decisions,
                                batch_for_commit,
                                project,
                            )
                        self.progress(
                            {
                                "event": "batch_committed",
                                "wave": wave_index,
                                "batch": next_batch_id,
                                "accepted": len(outcome.accepted),
                                "failed": len(outcome.failures),
                                "pending": len(project.units) - len(accepted),
                                "checkpoint_total": len(accepted),
                                "requests": outcome.request_count,
                                "duration_seconds": round(outcome.duration_seconds, 3),
                                "accepted_units_per_second": self._accepted_rate(
                                    len(accepted) - accepted_at_start, run_started
                                ),
                                "eta_seconds": self._eta(
                                    len(project.units) - len(accepted),
                                    len(accepted) - accepted_at_start,
                                    run_started,
                                ),
                                "provider": self._provider_activity(),
                                "glossary_revision": glossary_store.revision
                                if glossary_store is not None
                                else None,
                                "glossary_pending": self._pending_count(glossary_store),
                            }
                        )
                        next_batch_id += 1
            if worker_future is not None:
                self._collect_worker_result(worker_future)
        return failures

    def _collect_worker_result(self, future: Future[int]) -> None:
        try:
            processed = future.result()
        except (ProviderError, ValidationError) as error:
            self.progress({"event": "glossary_worker_failed", "reason": str(error)})
        else:
            self.progress({"event": "glossary_worker_completed", "processed": processed})

    def _execute_batch(
        self,
        batch: TranslationBatch,
        settings: PipelineSettings,
        base_current: dict[str, AcceptedTranslation],
        glossary_snapshot: tuple[GlossaryEntry, ...],
        on_partial: Callable[[dict[str, AcceptedTranslation]], None],
    ) -> BatchOutcome:
        started = time.monotonic()
        if settings.mode == "review":
            outcome = ReviewRecovery(
                provider=self.translation_provider,
                model=settings.model,
                project_context=settings.project_context,
                retries=settings.retries,
                on_partial=on_partial,
            ).resolve(
                batch.units,
                {unit.unit_id: base_current[unit.unit_id] for unit in batch.units},
            )
        else:
            outcome = TranslationRecovery(
                provider=self.translation_provider,
                model=settings.model,
                project_context=settings.project_context,
                retries=settings.retries,
                relevant_glossary=lambda _: glossary_snapshot,
                allow_terminology_decisions=settings.glossary_enabled,
                on_partial=on_partial,
            ).resolve(batch.units)
        outcome.duration_seconds = time.monotonic() - started
        return outcome

    @staticmethod
    def _accepted_rate(accepted_count: int, started: float) -> float:
        elapsed = max(0.001, time.monotonic() - started)
        return round(accepted_count / elapsed, 2)

    @staticmethod
    def _eta(remaining: int, accepted_count: int, started: float) -> float | None:
        rate = LocalizationPipeline._accepted_rate(accepted_count, started)
        return round(remaining / rate, 1) if rate > 0 else None

    def _provider_activity(self) -> dict[str, int] | None:
        capacity = getattr(self.translation_provider, "capacity", None)
        return capacity.snapshot() if capacity is not None else None

    @staticmethod
    def _pending_count(store: GlossaryStore | None) -> int:
        return store.pending_task_count() if store is not None else 0

    def _run_glossary_once(self, path: Path, settings: PipelineSettings) -> int:
        with GlossaryStore(path) as store:
            worker = GlossaryWorker(
                provider=self.glossary_provider,
                model=settings.glossary_model,
                project_context=settings.project_context,
            )
            return worker.run_once(store)

    def _drain_glossary(self, path: Path, settings: PipelineSettings) -> None:
        while True:
            processed = self._run_glossary_once(path, settings)
            with GlossaryStore(path) as store:
                pending = store.pending_task_count()
            if pending == 0:
                return
            if processed == 0:
                raise ValidationError("Glossary drain made no progress while pending tasks remain")

    @staticmethod
    def _route_terminology_decisions(
        store: GlossaryStore,
        decisions: list[dict[str, str]],
        batch: TranslationBatch,
        project: SourceProject,
    ) -> None:
        corpus = "\n".join(unit.source_text.casefold() for unit in project.units)
        evidence_unit_id = batch.units[0].unit_id
        for decision in decisions:
            source_term = decision["source_term"].strip()
            normalized = source_term.casefold()
            word_count = len(re.findall(r"\w+", source_term))
            if (
                word_count == 0
                or word_count > 5
                or "__KEEP_" in source_term
                or corpus.count(normalized) < 2
            ):
                continue
            store.queue_task(
                signal="terminology_decision",
                source_term=source_term,
                candidate_target=decision["target_term"],
                scope=decision["scope"],
                evidence_unit_id=evidence_unit_id,
            )
