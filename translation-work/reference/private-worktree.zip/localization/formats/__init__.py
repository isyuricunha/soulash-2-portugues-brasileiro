"""Repository-specific format handlers."""

from localization.formats.soulash import SoulashFormatHandler

__all__ = ["SoulashFormatHandler"]
