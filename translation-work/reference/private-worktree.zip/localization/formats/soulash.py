from __future__ import annotations

import copy
import hashlib
import json
import os
import shutil
import tempfile
from collections import Counter
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from localization.errors import FormatError, ProtectionError, ValidationError
from localization.models import (
    AcceptedTranslation,
    JsonPointer,
    JsonValue,
    ParsedFile,
    ReconstructionResult,
    SourceProject,
    TranslationUnit,
)
from localization.protection import (
    protect_text,
    restore_text,
    validate_protected_translation,
    validate_restored_translation,
)

SOURCE_SCHEMA_REVISION = "soulash-source-v2"
INCLUDED_DIRECTORIES = {"abilities", "buildings", "entities", "events", "milestones", "npc"}
INCLUDED_ROOT_FILES = {
    "ability_amplifiers.json",
    "ability_stackers.json",
    "building_groups.json",
    "building_names.json",
    "character.json",
    "conversations.json",
    "dialogues.json",
    "goals.json",
    "language_metadata.json",
    "locations.json",
    "messages.json",
    "passives.json",
    "region_names.json",
    "skills.json",
    "tutorial.json",
    "weather.json",
}
SCALAR_KEYS = {
    "affix",
    "ally_dialogue",
    "announcement",
    "answer_negative",
    "answer_positive",
    "begin",
    "death_text",
    "description",
    "dialogue",
    "end",
    "fail",
    "failure",
    "failure_message",
    "flavor",
    "format",
    "full_name",
    "history_event",
    "label",
    "long",
    "message",
    "monologue",
    "name",
    "objective",
    "orphan_surname",
    "rumor",
    "short",
    "success",
    "success_message",
    "text",
    "title",
    "trigger_message",
}
STRING_LIST_KEYS = {
    "ability_requirement",
    "ability_target",
    "ai_behaviors",
    "ally_dialogue",
    "aoe_shape",
    "attackNames",
    "beginning",
    "core_names",
    "crimes",
    "day_part",
    "desert",
    "formats",
    "hit_location",
    "item_type",
    "monologue",
    "names",
    "player_dialogue",
    "precipitations",
    "prefixes",
    "rarity",
    "rumors",
    "skill_levels",
    "suffixes",
    "tag",
    "temperatures",
    "weapon_type",
    "year_part",
}
GENDER_VALUES = {"masculine", "feminine"}


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _canonical_json(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode(
        "utf-8"
    )


def _pointer_label(pointer: JsonPointer) -> str:
    return "/" + "/".join(str(part).replace("~", "~0").replace("/", "~1") for part in pointer)


def _get_pointer(root: JsonValue, pointer: JsonPointer) -> JsonValue:
    current: JsonValue = root
    for part in pointer:
        if (isinstance(part, int) and isinstance(current, list)) or (
            isinstance(part, str) and isinstance(current, dict)
        ):
            current = current[part]
        else:
            raise ValidationError(f"Invalid JSON pointer {_pointer_label(pointer)}")
    return current


def _set_pointer(root: JsonValue, pointer: JsonPointer, value: JsonValue) -> None:
    if not pointer:
        raise ValidationError("The JSON root cannot be replaced by a translation unit")
    parent = _get_pointer(root, pointer[:-1])
    leaf = pointer[-1]
    if (isinstance(leaf, int) and isinstance(parent, list)) or (
        isinstance(leaf, str) and isinstance(parent, dict)
    ):
        parent[leaf] = value
    else:
        raise ValidationError(f"Invalid destination pointer {_pointer_label(pointer)}")


def _delete_pointer(root: JsonValue, pointer: JsonPointer) -> None:
    if not pointer:
        raise ValidationError("The JSON root cannot be deleted")
    parent = _get_pointer(root, pointer[:-1])
    leaf = pointer[-1]
    if isinstance(leaf, int) and isinstance(parent, list):
        del parent[leaf]
    elif isinstance(leaf, str) and isinstance(parent, dict):
        if leaf not in parent:
            raise ValidationError(f"Missing destination pointer {_pointer_label(pointer)}")
        del parent[leaf]
    else:
        raise ValidationError(f"Invalid destination pointer {_pointer_label(pointer)}")


def _stable_list_segment(item: JsonValue, occurrence: int) -> str:
    if isinstance(item, dict) and isinstance(item.get("id"), (str, int)):
        return f"@id={item['id']}#{occurrence}"
    digest = _sha256_bytes(_canonical_json(item))[:16]
    return f"@value={digest}#{occurrence}"


class SoulashFormatHandler:
    def discover(self, root: Path) -> list[Path]:
        if not root.is_dir():
            raise FormatError(f"Source directory does not exist: {root}")
        discovered: list[Path] = []
        for path in root.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in {".json", ".txt"}:
                continue
            relative = path.relative_to(root)
            if len(relative.parts) == 1:
                if path.name in INCLUDED_ROOT_FILES:
                    discovered.append(path)
            elif relative.parts[0] in INCLUDED_DIRECTORIES:
                discovered.append(path)
        return sorted(discovered, key=lambda path: path.relative_to(root).as_posix().casefold())

    def load(self, root: Path) -> SourceProject:
        files: dict[str, ParsedFile] = {}
        units: list[TranslationUnit] = []
        manifest_entries: list[tuple[str, str]] = []
        for path in self.discover(root):
            relative_path = path.relative_to(root).as_posix()
            raw_bytes = path.read_bytes()
            manifest_entries.append((relative_path, _sha256_bytes(raw_bytes)))
            if path.suffix.lower() == ".txt":
                files[relative_path] = ParsedFile(
                    relative_path=relative_path,
                    source_path=path,
                    kind="txt",
                    raw_bytes=raw_bytes,
                )
                continue
            try:
                text = raw_bytes.decode("utf-8")
            except UnicodeDecodeError as error:
                raise FormatError(f"JSON is not UTF-8: {path}") from error
            try:
                data = json.loads(text, object_pairs_hook=self._reject_duplicate_keys)
            except (json.JSONDecodeError, ValueError) as error:
                raise FormatError(f"Invalid JSON source {path}: {error}") from error
            files[relative_path] = ParsedFile(
                relative_path=relative_path,
                source_path=path,
                kind="json",
                data=data,
                raw_bytes=raw_bytes,
            )
            if relative_path != "language_metadata.json":
                units.extend(self._extract_file_units(relative_path, data))
        unit_ids = [unit.unit_id for unit in units]
        duplicates = [unit_id for unit_id, count in Counter(unit_ids).items() if count > 1]
        if duplicates:
            raise FormatError(f"Duplicate stable unit IDs: {duplicates[:5]}")
        manifest_hash = _sha256_bytes(_canonical_json(manifest_entries))
        return SourceProject(root=root, files=files, units=units, manifest_hash=manifest_hash)

    @staticmethod
    def _reject_duplicate_keys(pairs: list[tuple[str, JsonValue]]) -> dict[str, JsonValue]:
        result: dict[str, JsonValue] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate JSON key: {key}")
            result[key] = value
        return result

    def _extract_file_units(self, relative_path: str, data: JsonValue) -> list[TranslationUnit]:
        units: list[TranslationUnit] = []

        def emit(
            source_text: str,
            pointer: JsonPointer,
            stable_parts: tuple[str, ...],
            context: str,
            *,
            output_pointer: JsonPointer | None = None,
            synthetic: bool = False,
            gender_eligible: bool = False,
        ) -> None:
            if not source_text.strip():
                return
            protected = protect_text(source_text)
            stable_path = "/".join(stable_parts)
            identity = f"{SOURCE_SCHEMA_REVISION}\0{relative_path}\0{stable_path}"
            unit_id = "s2-" + hashlib.sha256(identity.encode("utf-8")).hexdigest()[:24]
            units.append(
                TranslationUnit(
                    unit_id=unit_id,
                    relative_path=relative_path,
                    pointer=pointer,
                    stable_path=stable_path,
                    source_text=source_text,
                    protected=protected,
                    context=context,
                    output_pointer=output_pointer,
                    synthetic=synthetic,
                    gender_eligible=gender_eligible,
                )
            )

        def walk(value: JsonValue, pointer: JsonPointer, stable_parts: tuple[str, ...]) -> None:
            if isinstance(value, dict):
                for key, child in value.items():
                    child_pointer = pointer + (key,)
                    child_stable = stable_parts + (key,)
                    if isinstance(child, str) and self._is_scalar_translatable(
                        relative_path, key, pointer
                    ):
                        is_root_entity_name = relative_path.startswith(
                            "entities/"
                        ) and child_pointer == ("name",)
                        emit(
                            child,
                            child_pointer,
                            child_stable,
                            self._context(relative_path, child_pointer),
                            gender_eligible=is_root_entity_name,
                        )
                        if (
                            relative_path.startswith("entities/")
                            and child_pointer[-2:] == ("resource", "affix")
                            and child.strip()
                        ):
                            emit(
                                child,
                                child_pointer,
                                child_stable + ("@feminine",),
                                self._context(relative_path, child_pointer)
                                + "; translate as the feminine adjective form",
                                output_pointer=pointer + ("feminine_affix",),
                                synthetic=True,
                            )
                    elif isinstance(child, list) and key in STRING_LIST_KEYS:
                        self._walk_string_list(
                            child,
                            child_pointer,
                            child_stable,
                            relative_path,
                            emit,
                        )
                    else:
                        walk(child, child_pointer, child_stable)
            elif isinstance(value, list):
                occurrences: Counter[str] = Counter()
                for index, child in enumerate(value):
                    fingerprint = _sha256_bytes(_canonical_json(child))[:16]
                    if isinstance(child, dict) and isinstance(child.get("id"), (str, int)):
                        occurrence_key = f"id:{child['id']}"
                    else:
                        occurrence_key = f"value:{fingerprint}"
                    occurrence = occurrences[occurrence_key]
                    occurrences[occurrence_key] += 1
                    segment = _stable_list_segment(child, occurrence)
                    walk(child, pointer + (index,), stable_parts + (segment,))

        walk(data, (), ())
        return units

    @staticmethod
    def _walk_string_list(
        value: list[JsonValue],
        pointer: JsonPointer,
        stable_parts: tuple[str, ...],
        relative_path: str,
        emit: Any,
    ) -> None:
        occurrences: Counter[str] = Counter()

        def walk_list(
            items: list[JsonValue],
            current_pointer: JsonPointer,
            current_stable: tuple[str, ...],
        ) -> None:
            for index, item in enumerate(items):
                if isinstance(item, str):
                    digest = _sha256_bytes(item.encode("utf-8"))[:16]
                    occurrence = occurrences[digest]
                    occurrences[digest] += 1
                    emit(
                        item,
                        current_pointer + (index,),
                        current_stable + (f"@text={digest}#{occurrence}",),
                        SoulashFormatHandler._context(relative_path, current_pointer + (index,)),
                    )
                elif isinstance(item, list):
                    walk_list(
                        item,
                        current_pointer + (index,),
                        current_stable + (f"@list={index}",),
                    )

        walk_list(value, pointer, stable_parts)

    @staticmethod
    def _is_scalar_translatable(relative_path: str, key: str, parent: JsonPointer) -> bool:
        if relative_path == "messages.json":
            return key != "id"
        if relative_path == "dialogues.json" and key == "name":
            return False
        if key not in SCALAR_KEYS:
            return False
        if key == "affix":
            return relative_path.startswith("entities/") and parent[-1:] == ("resource",)
        return True

    @staticmethod
    def _context(relative_path: str, pointer: JsonPointer) -> str:
        section = relative_path.split("/", 1)[0]
        return f"Soulash 2 {section}; {relative_path} {_pointer_label(pointer)}"

    def reconstruct(
        self,
        project: SourceProject,
        accepted: dict[str, AcceptedTranslation],
        destination_root: Path,
    ) -> ReconstructionResult:
        expected_ids = {unit.unit_id for unit in project.units}
        if set(accepted) != expected_ids:
            missing = sorted(expected_ids - set(accepted))
            extra = sorted(set(accepted) - expected_ids)
            raise ValidationError(
                f"Cannot reconstruct partial output; missing={len(missing)}, extra={len(extra)}"
            )
        stage_parent = destination_root.parent
        stage_parent.mkdir(parents=True, exist_ok=True)
        stage = Path(tempfile.mkdtemp(prefix=f".{destination_root.name}-", dir=stage_parent))
        try:
            translation_root = stage / "translations" / "ptbr"
            translation_root.mkdir(parents=True)
            units_by_file: dict[str, list[TranslationUnit]] = {}
            for unit in project.units:
                units_by_file.setdefault(unit.relative_path, []).append(unit)
            for relative_path, parsed_file in project.files.items():
                output_path = translation_root / Path(relative_path)
                output_path.parent.mkdir(parents=True, exist_ok=True)
                if parsed_file.kind == "txt":
                    if parsed_file.raw_bytes is None:
                        raise ValidationError(f"TXT source bytes are missing: {relative_path}")
                    output_path.write_bytes(parsed_file.raw_bytes)
                    continue
                if parsed_file.data is None:
                    raise ValidationError(f"JSON source data is missing: {relative_path}")
                rebuilt = copy.deepcopy(parsed_file.data)
                if relative_path == "language_metadata.json":
                    rebuilt = {"id": "ptbr", "name": "Português Brasileiro"}
                else:
                    for unit in units_by_file.get(relative_path, []):
                        result = accepted[unit.unit_id]
                        validate_protected_translation(unit.protected, result.protected_text)
                        restored = restore_text(unit.protected, result.protected_text)
                        if restored != result.restored_text:
                            raise ValidationError(
                                f"Restored checkpoint mismatch for {unit.unit_id}"
                            )
                        _set_pointer(rebuilt, unit.destination_pointer, restored)
                        if unit.gender_eligible:
                            if result.grammatical_gender not in GENDER_VALUES:
                                raise ValidationError(
                                    f"Missing grammatical gender for {unit.unit_id}"
                                )
                            if not isinstance(rebuilt, dict):
                                raise ValidationError("Entity root must be an object")
                            rebuilt.pop("feminine_form", None)
                            rebuilt.pop("neuter_form", None)
                            if result.grammatical_gender == "feminine":
                                rebuilt["feminine_form"] = True
                output_path.write_text(
                    json.dumps(rebuilt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
                )
            self._write_mod_metadata(stage)
            validation = self.validate_reconstruction(project, accepted, stage)
            manifest = {
                "schema_version": 1,
                "source_manifest": project.manifest_hash,
                "source_schema_revision": SOURCE_SCHEMA_REVISION,
                "files": validation["files"],
                "units": len(project.units),
            }
            (stage / "translation-manifest.json").write_text(
                json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
            )
            if destination_root.exists():
                raise ValidationError(
                    "Guarded promotion refuses to replace an existing destination: "
                    f"{destination_root}"
                )
            os.replace(stage, destination_root)
            return ReconstructionResult(
                root=destination_root,
                file_count=len(project.files),
                unit_count=len(project.units),
                manifest=manifest,
            )
        except Exception:
            shutil.rmtree(stage, ignore_errors=True)
            raise

    @staticmethod
    def _mod_metadata() -> dict[str, JsonValue]:
        return {
            "author": "Yuri Cunha",
            "description": "Brazilian Portuguese localization for Soulash 2.",
            "disable_transition_tiles": True,
            "draw_all_glyphs": True,
            "game_required": "0.10.1",
            "mods_required": [],
            "name": "Português Brasileiro - PTBR",
            "version": "0.1.0",
        }

    @classmethod
    def _write_mod_metadata(cls, stage: Path) -> None:
        mod = cls._mod_metadata()
        language = {"id": "ptbr", "name": "Português Brasileiro"}
        (stage / "mod.json").write_text(
            json.dumps(mod, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        (stage / "language_metadata.json").write_text(
            json.dumps(language, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )

    def validate_reconstruction(
        self,
        project: SourceProject,
        accepted: dict[str, AcceptedTranslation],
        target_root: Path,
    ) -> dict[str, Any]:
        translation_root = target_root / "translations" / "ptbr"
        target_files = {
            path.relative_to(translation_root).as_posix(): path
            for path in translation_root.rglob("*")
            if path.is_file()
        }
        if set(target_files) != set(project.files):
            raise ValidationError("Target file set does not match the source snapshot")
        for relative_path, parsed_file in project.files.items():
            target_path = target_files[relative_path]
            if parsed_file.kind == "txt":
                if target_path.read_bytes() != parsed_file.raw_bytes:
                    raise ValidationError(f"TXT file changed unexpectedly: {relative_path}")
                continue
            try:
                target_data = json.loads(
                    target_path.read_text(encoding="utf-8"),
                    object_pairs_hook=self._reject_duplicate_keys,
                )
            except (json.JSONDecodeError, ValueError) as error:
                raise ValidationError(f"Invalid rebuilt JSON {relative_path}: {error}") from error
            if relative_path == "language_metadata.json":
                if target_data != {"id": "ptbr", "name": "Português Brasileiro"}:
                    raise ValidationError("Invalid runtime language metadata")
                continue
            for unit in (item for item in project.units if item.relative_path == relative_path):
                value = _get_pointer(target_data, unit.destination_pointer)
                if value != accepted[unit.unit_id].restored_text:
                    raise ValidationError(f"Rebuilt unit mismatch: {unit.unit_id}")
        hashes = {
            relative: _sha256_bytes(path.read_bytes())
            for relative, path in sorted(target_files.items())
        }
        return {"files": hashes}

    def validate_published(self, project: SourceProject, target_root: Path) -> dict[str, Any]:
        if not target_root.is_dir():
            raise ValidationError(f"Published target directory does not exist: {target_root}")
        expected_root_entries = {
            "language_metadata.json",
            "mod.json",
            "translation-manifest.json",
            "translations",
        }
        if {path.name for path in target_root.iterdir()} != expected_root_entries:
            raise ValidationError("Published mod root contains missing or unexpected entries")
        try:
            root_language = json.loads(
                (target_root / "language_metadata.json").read_text(encoding="utf-8"),
                object_pairs_hook=self._reject_duplicate_keys,
            )
            mod_metadata = json.loads(
                (target_root / "mod.json").read_text(encoding="utf-8"),
                object_pairs_hook=self._reject_duplicate_keys,
            )
        except (OSError, json.JSONDecodeError, ValueError) as error:
            raise ValidationError(f"Invalid published root metadata: {error}") from error
        if root_language != {"id": "ptbr", "name": "Português Brasileiro"}:
            raise ValidationError("Invalid published root language metadata")
        if mod_metadata != self._mod_metadata():
            raise ValidationError("Published mod metadata does not match the verified contract")
        manifest_path = target_root / "translation-manifest.json"
        if not manifest_path.is_file():
            raise ValidationError("Published target is missing translation-manifest.json")
        try:
            manifest = json.loads(
                manifest_path.read_text(encoding="utf-8"),
                object_pairs_hook=self._reject_duplicate_keys,
            )
        except (json.JSONDecodeError, ValueError) as error:
            raise ValidationError(f"Invalid translation manifest: {error}") from error
        if not isinstance(manifest, dict):
            raise ValidationError("Translation manifest root must be an object")
        if manifest.get("source_manifest") != project.manifest_hash:
            raise ValidationError("Published target was built from a different source manifest")
        if manifest.get("units") != len(project.units):
            raise ValidationError("Published target unit count does not match the source")

        translation_root = target_root / "translations" / "ptbr"
        target_files = {
            path.relative_to(translation_root).as_posix(): path
            for path in translation_root.rglob("*")
            if path.is_file()
        }
        if set(target_files) != set(project.files):
            raise ValidationError("Published target file set does not match the source snapshot")
        expected_hashes = manifest.get("files")
        if not isinstance(expected_hashes, dict):
            raise ValidationError("Translation manifest files field must be an object")
        actual_hashes = {
            relative_path: _sha256_bytes(path.read_bytes())
            for relative_path, path in sorted(target_files.items())
        }
        if actual_hashes != expected_hashes:
            raise ValidationError("Published target hashes do not match its manifest")

        units_by_file: dict[str, list[TranslationUnit]] = {}
        for unit in project.units:
            units_by_file.setdefault(unit.relative_path, []).append(unit)
        for relative_path, parsed_file in project.files.items():
            target_path = target_files[relative_path]
            if parsed_file.kind == "txt":
                if target_path.read_bytes() != parsed_file.raw_bytes:
                    raise ValidationError(f"Published TXT changed: {relative_path}")
                continue
            if parsed_file.data is None:
                raise ValidationError(f"Missing parsed source JSON: {relative_path}")
            try:
                target_data = json.loads(
                    target_path.read_text(encoding="utf-8"),
                    object_pairs_hook=self._reject_duplicate_keys,
                )
            except (json.JSONDecodeError, ValueError) as error:
                raise ValidationError(f"Invalid published JSON {relative_path}: {error}") from error
            if relative_path == "language_metadata.json":
                if target_data != {"id": "ptbr", "name": "Português Brasileiro"}:
                    raise ValidationError("Invalid published runtime language metadata")
                continue
            source_structure = copy.deepcopy(parsed_file.data)
            target_structure = copy.deepcopy(target_data)
            for unit in units_by_file.get(relative_path, []):
                if unit.synthetic:
                    _delete_pointer(target_structure, unit.destination_pointer)
                    continue
                target_value = _get_pointer(target_data, unit.destination_pointer)
                if not isinstance(target_value, str) or not target_value.strip():
                    raise ValidationError(f"Published translation is empty: {unit.unit_id}")
                try:
                    validate_restored_translation(unit.protected, target_value)
                except ProtectionError as error:
                    raise ValidationError(
                        f"Published technical-token mismatch: {unit.unit_id}: {error}"
                    ) from error
                _set_pointer(source_structure, unit.pointer, "__TRANSLATED_UNIT__")
                _set_pointer(target_structure, unit.destination_pointer, "__TRANSLATED_UNIT__")
                if unit.gender_eligible:
                    if not isinstance(source_structure, dict) or not isinstance(
                        target_structure, dict
                    ):
                        raise ValidationError("Published entity root must be an object")
                    if "neuter_form" in target_structure:
                        raise ValidationError("PT-BR entity cannot use a neuter form")
                    if target_structure.get("feminine_form") is not True and (
                        "feminine_form" in target_structure
                    ):
                        raise ValidationError("PT-BR feminine_form must be true when present")
                    source_structure.pop("feminine_form", None)
                    source_structure.pop("neuter_form", None)
                    target_structure.pop("feminine_form", None)
                    target_structure.pop("neuter_form", None)
            if source_structure != target_structure:
                raise ValidationError(
                    f"Published non-translatable structure changed: {relative_path}"
                )
        return {"files": actual_hashes, "units": len(project.units)}

    def refresh_source(self, game_core_root: Path, snapshot_root: Path) -> dict[str, Any]:
        discovered = self.discover(game_core_root)
        snapshot_root.parent.mkdir(parents=True, exist_ok=True)
        stage = Path(tempfile.mkdtemp(prefix=f".{snapshot_root.name}-", dir=snapshot_root.parent))
        try:
            translation_root = stage / "translations" / "ptbr"
            entries: list[dict[str, Any]] = []
            for source_path in discovered:
                relative = source_path.relative_to(game_core_root)
                destination = translation_root / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source_path, destination)
                entries.append(
                    {
                        "path": relative.as_posix(),
                        "size": source_path.stat().st_size,
                        "sha256": _sha256_bytes(source_path.read_bytes()),
                    }
                )
            manifest = {
                "schema_version": 1,
                "source_schema_revision": SOURCE_SCHEMA_REVISION,
                "source_root": str(game_core_root.resolve()),
                "files": entries,
            }
            (stage / "source-manifest.json").write_text(
                json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
            )
            loaded = self.load(translation_root)
            copied_hashes = {
                relative_path: _sha256_bytes(parsed_file.raw_bytes or b"")
                for relative_path, parsed_file in loaded.files.items()
            }
            expected_hashes = {entry["path"]: entry["sha256"] for entry in entries}
            if copied_hashes != expected_hashes:
                raise ValidationError("Source changed while the guarded snapshot was being copied")
            manifest["manifest_hash"] = loaded.manifest_hash
            manifest["units"] = len(loaded.units)
            (stage / "source-manifest.json").write_text(
                json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
            )
            if snapshot_root.exists():
                raise ValidationError(
                    f"Source refresh refuses to replace an existing snapshot: {snapshot_root}"
                )
            os.replace(stage, snapshot_root)
            return manifest
        except Exception:
            shutil.rmtree(stage, ignore_errors=True)
            raise

    @staticmethod
    def source_hashes(root: Path, paths: Iterable[Path]) -> dict[str, str]:
        return {
            path.relative_to(root).as_posix(): _sha256_bytes(path.read_bytes()) for path in paths
        }
