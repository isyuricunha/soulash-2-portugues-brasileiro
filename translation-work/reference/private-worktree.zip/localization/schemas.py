from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass, field
from typing import Any

from localization.errors import ProtectionError, ValidationError
from localization.models import AcceptedTranslation, TranslationUnit
from localization.protection import restore_text, validate_protected_translation

KNOWN_ISSUE_CODES = {
    "accuracy",
    "fluency",
    "grammar",
    "style",
    "terminology",
    "token",
    "other",
}


def _exact_string_object(ids: list[str]) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {unit_id: {"type": "string", "minLength": 1} for unit_id in ids},
        "required": ids,
        "additionalProperties": False,
    }


def translation_schema(
    units: tuple[TranslationUnit, ...], *, allow_terminology_decisions: bool
) -> dict[str, Any]:
    unit_ids = [unit.unit_id for unit in units]
    gender_ids = [unit.unit_id for unit in units if unit.gender_eligible]
    properties: dict[str, Any] = {
        "translations": _exact_string_object(unit_ids),
        "grammatical_genders": {
            "type": "object",
            "properties": {
                unit_id: {"type": "string", "enum": ["masculine", "feminine"]}
                for unit_id in gender_ids
            },
            "required": gender_ids,
            "additionalProperties": False,
        },
    }
    required = ["translations", "grammatical_genders"]
    if allow_terminology_decisions:
        properties["terminology_decisions"] = {
            "type": "array",
            "maxItems": 3,
            "items": {
                "type": "object",
                "properties": {
                    "source_term": {"type": "string", "minLength": 2, "maxLength": 120},
                    "target_term": {"type": "string", "minLength": 1, "maxLength": 120},
                    "scope": {"type": "string", "minLength": 1, "maxLength": 120},
                    "reason": {"type": "string", "minLength": 1, "maxLength": 300},
                },
                "required": ["source_term", "target_term", "scope", "reason"],
                "additionalProperties": False,
            },
        }
        required.append("terminology_decisions")
    return {
        "type": "object",
        "properties": properties,
        "required": required,
        "additionalProperties": False,
    }


def review_schema(units: tuple[TranslationUnit, ...]) -> dict[str, Any]:
    unit_ids = [unit.unit_id for unit in units]
    return {
        "type": "object",
        "properties": {
            "reviews": {
                "type": "array",
                "minItems": len(unit_ids),
                "maxItems": len(unit_ids),
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string", "enum": unit_ids},
                        "decision": {"type": "string", "enum": ["keep", "revise"]},
                        "text": {"type": "string", "minLength": 1},
                        "issue_codes": {
                            "type": "array",
                            "maxItems": 8,
                            "items": {"type": "string", "maxLength": 40},
                        },
                    },
                    "required": ["id", "decision", "text", "issue_codes"],
                    "additionalProperties": False,
                },
            }
        },
        "required": ["reviews"],
        "additionalProperties": False,
    }


def glossary_resolution_schema(candidate_ids: tuple[int, ...]) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "resolutions": {
                "type": "array",
                "maxItems": len(candidate_ids),
                "items": {
                    "type": "object",
                    "properties": {
                        "candidate_id": {"type": "integer", "enum": list(candidate_ids)},
                        "target_term": {"type": "string", "minLength": 1, "maxLength": 120},
                        "status": {
                            "type": "string",
                            "enum": ["confirmed", "challenged", "conflicted", "preserved"],
                        },
                        "reason": {"type": "string", "minLength": 1, "maxLength": 300},
                    },
                    "required": ["candidate_id", "target_term", "status", "reason"],
                    "additionalProperties": False,
                },
            }
        },
        "required": ["resolutions"],
        "additionalProperties": False,
    }


def _reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValidationError(f"Provider JSON contains duplicate key: {key}")
        result[key] = value
    return result


def parse_json_object(raw: str) -> dict[str, Any]:
    if not raw.strip():
        raise ValidationError("Provider returned empty final content")
    try:
        value = json.loads(raw, object_pairs_hook=_reject_duplicate_keys)
    except json.JSONDecodeError as error:
        raise ValidationError(f"Provider returned malformed or wrapped JSON: {error}") from error
    if not isinstance(value, dict):
        raise ValidationError("Provider response root must be an object")
    return value


@dataclass(slots=True)
class ParsedTranslations:
    accepted: dict[str, AcceptedTranslation] = field(default_factory=dict)
    errors: dict[str, str] = field(default_factory=dict)
    terminology_decisions: list[dict[str, str]] = field(default_factory=list)
    metadata_error: str | None = None


def parse_translation_response(
    raw: str,
    units: tuple[TranslationUnit, ...],
    *,
    allow_terminology_decisions: bool,
) -> ParsedTranslations:
    root = parse_json_object(raw)
    allowed_root = {"translations", "grammatical_genders"}
    if allow_terminology_decisions:
        allowed_root.add("terminology_decisions")
    unexpected_root = set(root) - allowed_root
    if unexpected_root:
        raise ValidationError(f"Unexpected provider root fields: {sorted(unexpected_root)}")
    translations = root.get("translations")
    genders = root.get("grammatical_genders", {})
    if not isinstance(translations, dict) or not isinstance(genders, dict):
        raise ValidationError("translations and grammatical_genders must be objects")
    units_by_id = {unit.unit_id: unit for unit in units}
    extra_ids = (set(translations) | set(genders)) - set(units_by_id)
    if extra_ids:
        raise ValidationError(f"Provider returned unrequested IDs: {sorted(extra_ids)}")

    parsed = ParsedTranslations()
    for unit_id, unit in units_by_id.items():
        candidate = translations.get(unit_id)
        if not isinstance(candidate, str) or not candidate.strip():
            parsed.errors[unit_id] = "missing or non-empty-string translation"
            continue
        gender = genders.get(unit_id)
        if unit.gender_eligible and gender not in {"masculine", "feminine"}:
            parsed.errors[unit_id] = "missing or invalid grammatical gender"
            continue
        if not unit.gender_eligible and unit_id in genders:
            parsed.errors[unit_id] = "unexpected grammatical gender"
            continue
        try:
            validate_protected_translation(unit.protected, candidate)
            restored = restore_text(unit.protected, candidate)
        except (ProtectionError, ValidationError) as error:
            parsed.errors[unit_id] = str(error)
            continue
        parsed.accepted[unit_id] = AcceptedTranslation(
            unit_id=unit_id,
            protected_text=candidate,
            restored_text=restored,
            grammatical_gender=gender,
        )

    decisions = root.get("terminology_decisions", [])
    if allow_terminology_decisions:
        try:
            parsed.terminology_decisions = _validate_terminology_decisions(decisions)
        except ValidationError as error:
            parsed.metadata_error = str(error)
    elif "terminology_decisions" in root:
        raise ValidationError("Terminology decisions are disabled for this request")
    return parsed


def _validate_terminology_decisions(value: Any) -> list[dict[str, str]]:
    if not isinstance(value, list) or len(value) > 3:
        raise ValidationError("terminology_decisions must be an array of at most 3 items")
    required = {"source_term", "target_term", "scope", "reason"}
    decisions: list[dict[str, str]] = []
    for item in value:
        if not isinstance(item, dict) or set(item) != required:
            raise ValidationError("Terminology decision fields do not match the contract")
        if any(not isinstance(item[key], str) or not item[key].strip() for key in required):
            raise ValidationError("Terminology decision fields must be non-empty strings")
        decisions.append({key: item[key].strip() for key in required})
    return decisions


def parse_review_response(
    raw: str,
    units: tuple[TranslationUnit, ...],
    current: dict[str, AcceptedTranslation],
) -> tuple[dict[str, AcceptedTranslation], dict[str, tuple[str, ...]]]:
    root = parse_json_object(raw)
    if set(root) != {"reviews"} or not isinstance(root["reviews"], list):
        raise ValidationError("Review response must contain only a reviews array")
    units_by_id = {unit.unit_id: unit for unit in units}
    reviews = root["reviews"]
    ids = [item.get("id") for item in reviews if isinstance(item, dict)]
    if len(ids) != len(reviews) or Counter(ids) != Counter(units_by_id.keys()):
        raise ValidationError("Review IDs must match every requested ID exactly once")
    accepted: dict[str, AcceptedTranslation] = {}
    issue_codes: dict[str, tuple[str, ...]] = {}
    for item in reviews:
        if not isinstance(item, dict) or set(item) != {"id", "decision", "text", "issue_codes"}:
            raise ValidationError("Review item fields do not match the contract")
        unit_id = item["id"]
        decision = item["decision"]
        text = item["text"]
        codes = item["issue_codes"]
        if decision not in {"keep", "revise"} or not isinstance(text, str):
            raise ValidationError(f"Invalid review decision or text for {unit_id}")
        if not isinstance(codes, list) or any(not isinstance(code, str) for code in codes):
            raise ValidationError(f"Invalid issue_codes for {unit_id}")
        if decision == "keep" and text != current[unit_id].protected_text:
            raise ValidationError(f"Keep decision changed the supplied text for {unit_id}")
        unit = units_by_id[unit_id]
        validate_protected_translation(unit.protected, text)
        accepted[unit_id] = AcceptedTranslation(
            unit_id=unit_id,
            protected_text=text,
            restored_text=restore_text(unit.protected, text),
            grammatical_gender=current[unit_id].grammatical_gender,
        )
        issue_codes[unit_id] = tuple(
            code if code in KNOWN_ISSUE_CODES else "other" for code in codes
        )
    return accepted, issue_codes


def parse_glossary_resolution_response(
    raw: str, candidate_ids: tuple[int, ...]
) -> list[dict[str, object]]:
    root = parse_json_object(raw)
    if set(root) != {"resolutions"} or not isinstance(root["resolutions"], list):
        raise ValidationError("Glossary response must contain only a resolutions array")
    allowed_statuses = {"confirmed", "challenged", "conflicted", "preserved"}
    required = {"candidate_id", "target_term", "status", "reason"}
    seen: set[int] = set()
    resolutions: list[dict[str, object]] = []
    for item in root["resolutions"]:
        if not isinstance(item, dict) or set(item) != required:
            raise ValidationError("Glossary resolution fields do not match the contract")
        candidate_id = item["candidate_id"]
        if (
            not isinstance(candidate_id, int)
            or candidate_id not in candidate_ids
            or candidate_id in seen
        ):
            raise ValidationError("Glossary resolution contains an invalid or duplicate candidate")
        if item["status"] not in allowed_statuses:
            raise ValidationError(f"Invalid glossary resolution status for {candidate_id}")
        if any(
            not isinstance(item[key], str) or not item[key].strip()
            for key in ("target_term", "reason")
        ):
            raise ValidationError(f"Invalid glossary resolution text for {candidate_id}")
        seen.add(candidate_id)
        resolutions.append(item)
    return resolutions
