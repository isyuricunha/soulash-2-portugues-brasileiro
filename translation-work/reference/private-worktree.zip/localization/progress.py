from __future__ import annotations

import json
import sys
import time
from collections.abc import Callable
from typing import TextIO


class LiveProgressReporter:
    def __init__(
        self,
        *,
        progress_stream: TextIO | None = None,
        log_stream: TextIO | None = None,
        interactive: bool | None = None,
        verbose: bool = False,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.progress_stream = progress_stream or sys.stderr
        self.log_stream = log_stream or sys.stdout
        self.interactive = self.progress_stream.isatty() if interactive is None else interactive
        self.verbose = verbose
        self.clock = clock
        self.total = 0
        self.completed = 0
        self.completed_at_start = 0
        self.started_at: float | None = None
        self.rate: float | None = None
        self.eta_seconds: float | None = None
        self.last_line_length = 0
        self.rendered = False

    def __call__(self, event: dict[str, object]) -> None:
        event_name = str(event.get("event", ""))
        if self.verbose:
            self._write_verbose_event(event)

        if event_name == "generation_started":
            self.total = int(event.get("selected", 0))
            self.completed = int(event.get("reused", 0))
            self.completed_at_start = self.completed
            self.started_at = self.clock()
            self.rate = None
            self.eta_seconds = None
        elif event_name in {"partial_checkpoint_committed", "batch_committed"}:
            self.completed = int(event.get("checkpoint_total", self.completed))
            self._update_estimates(event)
        elif event_name in {"published", "publication_reused"}:
            self.completed = int(event.get("accepted", self.total))
            self._update_estimates(event)
        else:
            if self.interactive and self.started_at is not None and not self.rendered:
                self._render()
            return

        if self.interactive:
            self._render()

    def finish(self) -> None:
        if not self.interactive or not self.rendered:
            return
        self.progress_stream.write("\n")
        self.progress_stream.flush()
        self.rendered = False
        self.last_line_length = 0

    def _update_estimates(self, event: dict[str, object]) -> None:
        event_rate = event.get("accepted_units_per_second")
        event_eta = event.get("eta_seconds")
        if isinstance(event_rate, int | float):
            self.rate = float(event_rate)
        else:
            self.rate = self._calculated_rate()
        if isinstance(event_eta, int | float):
            self.eta_seconds = max(0.0, float(event_eta))
        else:
            remaining = max(0, self.total - self.completed)
            self.eta_seconds = remaining / self.rate if self.rate and self.rate > 0 else None

    def _calculated_rate(self) -> float | None:
        if self.started_at is None:
            return None
        elapsed = max(0.001, self.clock() - self.started_at)
        newly_completed = max(0, self.completed - self.completed_at_start)
        return newly_completed / elapsed if newly_completed else None

    def _render(self) -> None:
        line = self._line()
        padding = " " * max(0, self.last_line_length - len(line))
        self.progress_stream.write(f"\r{line}{padding}")
        self.progress_stream.flush()
        self.last_line_length = len(line)
        self.rendered = True

    def _line(self) -> str:
        fraction = min(1.0, self.completed / self.total) if self.total else 0.0
        filled = round(fraction * 20)
        bar = "#" * filled + "-" * (20 - filled)
        rate = f"{self.rate:.2f} units/s" if self.rate is not None else "-- units/s"
        eta = self._format_duration(self.eta_seconds)
        return (
            f"Progress [{bar}] {fraction * 100:5.1f}% | "
            f"{self.completed}/{self.total} | {rate} | ETA {eta}"
        )

    def _write_verbose_event(self, event: dict[str, object]) -> None:
        if self.interactive and self.rendered:
            self.progress_stream.write(f"\r{' ' * self.last_line_length}\r")
            self.progress_stream.flush()
            self.rendered = False
        print(
            json.dumps(event, ensure_ascii=False, sort_keys=True),
            file=self.log_stream,
            flush=True,
        )

    @staticmethod
    def _format_duration(seconds: float | None) -> str:
        if seconds is None:
            return "--:--:--"
        rounded = max(0, round(seconds))
        hours, remainder = divmod(rounded, 3_600)
        minutes, seconds_part = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{seconds_part:02d}"
