from __future__ import annotations

import os
import shutil
from contextlib import suppress
from datetime import UTC, datetime
from pathlib import Path

from localization.errors import ValidationError
from localization.formats.soulash import SoulashFormatHandler
from localization.models import AcceptedTranslation, ReconstructionResult, SourceProject


class PublicationManager:
    def __init__(self, handler: SoulashFormatHandler) -> None:
        self.handler = handler

    def publish(
        self,
        project: SourceProject,
        accepted: dict[str, AcceptedTranslation],
        output_root: Path,
    ) -> tuple[ReconstructionResult, Path | None]:
        output_root.parent.mkdir(parents=True, exist_ok=True)
        staging_parent = output_root.parent / ".staging"
        staging_parent.mkdir(exist_ok=True)
        timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%S%fZ")
        candidate = staging_parent / f"{output_root.name}-{timestamp}"
        backup: Path | None = None
        result: ReconstructionResult | None = None
        try:
            result = self.handler.reconstruct(project, accepted, candidate)
            self.handler.validate_published(project, candidate)
            if output_root.exists():
                backup = output_root.parent / f"{output_root.name}.previous-{timestamp}"
                if backup.exists():
                    raise ValidationError(f"Publication backup already exists: {backup}")
                os.replace(output_root, backup)
            os.replace(candidate, output_root)
        except Exception:
            if backup is not None and backup.exists() and not output_root.exists():
                os.replace(backup, output_root)
            raise
        finally:
            if candidate.exists():
                shutil.rmtree(candidate)
            with suppress(OSError):
                staging_parent.rmdir()
        if result is None:
            raise ValidationError("Publication did not produce a reconstruction result")
        result.root = output_root
        return result, backup
