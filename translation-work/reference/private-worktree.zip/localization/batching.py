from __future__ import annotations

import math
import random
import time
from collections.abc import Callable, Iterable

from localization.errors import (
    ProtectionError,
    ProviderError,
    TransientProviderError,
    ValidationError,
)
from localization.models import (
    AcceptedTranslation,
    BatchOutcome,
    GlossaryEntry,
    TranslationBatch,
    TranslationUnit,
)
from localization.prompts import review_messages, translation_messages
from localization.provider import Provider, make_request
from localization.schemas import (
    parse_review_response,
    parse_translation_response,
    review_schema,
    translation_schema,
)


class AdaptiveBatcher:
    def __init__(
        self,
        *,
        maximum_units: int,
        maximum_characters: int,
        maximum_estimated_input_tokens: int | None = None,
    ) -> None:
        if maximum_units < 1 or maximum_characters < 1:
            raise ValueError("Batch limits must be positive")
        self.maximum_units = maximum_units
        self.maximum_characters = maximum_characters
        self.maximum_estimated_input_tokens = maximum_estimated_input_tokens or max(
            1, maximum_characters // 3
        )

    @staticmethod
    def _metrics(unit: TranslationUnit) -> tuple[int, int, int]:
        characters = len(unit.protected.text) + len(unit.context)
        protected_count = len(unit.protected.tokens)
        structural_count = sum(
            token.category.value != "independent" for token in unit.protected.tokens
        )
        estimated_tokens = math.ceil(characters / 4) + protected_count * 4 + structural_count * 8
        return characters, estimated_tokens, protected_count

    def create_batches(self, units: Iterable[TranslationUnit]) -> list[TranslationBatch]:
        batches: list[TranslationBatch] = []
        current: list[TranslationUnit] = []
        current_characters = 0
        current_tokens = 0
        current_protected = 0

        def flush() -> None:
            nonlocal current, current_characters, current_tokens, current_protected
            if not current:
                return
            batches.append(
                TranslationBatch(
                    batch_id=len(batches),
                    units=tuple(current),
                    character_count=current_characters,
                    estimated_input_tokens=current_tokens,
                    protected_token_count=current_protected,
                )
            )
            current = []
            current_characters = 0
            current_tokens = 0
            current_protected = 0

        for unit in units:
            characters, tokens, protected = self._metrics(unit)
            would_overflow = current and (
                len(current) >= self.maximum_units
                or current_characters + characters > self.maximum_characters
                or current_tokens + tokens > self.maximum_estimated_input_tokens
            )
            if would_overflow:
                flush()
            current.append(unit)
            current_characters += characters
            current_tokens += tokens
            current_protected += protected
            if characters > self.maximum_characters or tokens > self.maximum_estimated_input_tokens:
                flush()
        flush()
        return batches


class TranslationRecovery:
    def __init__(
        self,
        *,
        provider: Provider,
        model: str,
        project_context: str,
        retries: int,
        relevant_glossary: Callable[[tuple[TranslationUnit, ...]], Iterable[GlossaryEntry]],
        allow_terminology_decisions: bool,
        on_partial: Callable[[dict[str, AcceptedTranslation]], None] | None = None,
        sleep: Callable[[float], None] = time.sleep,
        random_source: random.Random | None = None,
    ) -> None:
        if retries < 0:
            raise ValueError("Retries cannot be negative")
        self.provider = provider
        self.model = model
        self.project_context = project_context
        self.retries = retries
        self.relevant_glossary = relevant_glossary
        self.allow_terminology_decisions = allow_terminology_decisions
        self.on_partial = on_partial or (lambda _: None)
        self.sleep = sleep
        self.random_source = random_source or random.Random()

    def resolve(self, units: tuple[TranslationUnit, ...]) -> BatchOutcome:
        outcome = BatchOutcome()
        if not units:
            return outcome
        root_budget = max(
            self.retries + 1,
            min(128, (self.retries + 1) * (2 * len(units) - 1)),
        )
        budget = [root_budget]
        self._resolve_subset(units, outcome, budget)
        for unit in units:
            if unit.unit_id not in outcome.accepted and unit.unit_id not in outcome.failures:
                outcome.failures[unit.unit_id] = "shared root-batch request budget exhausted"
        outcome.request_count = root_budget - budget[0]
        return outcome

    def _resolve_subset(
        self,
        units: tuple[TranslationUnit, ...],
        outcome: BatchOutcome,
        budget: list[int],
    ) -> None:
        pending = tuple(unit for unit in units if unit.unit_id not in outcome.accepted)
        if not pending or budget[0] <= 0:
            return
        feedback: str | None = None
        last_errors = {unit.unit_id: "not attempted" for unit in pending}
        transient_failure: str | None = None
        for attempt in range(self.retries + 1):
            if not pending or budget[0] <= 0:
                break
            budget[0] -= 1
            request = make_request(
                operation="translation",
                schema_name="soulash_translation",
                schema=translation_schema(
                    pending,
                    allow_terminology_decisions=self.allow_terminology_decisions,
                ),
                messages=translation_messages(
                    pending,
                    project_context=self.project_context,
                    glossary=self.relevant_glossary(pending),
                    corrective_feedback=feedback,
                ),
                model=self.model,
            )
            try:
                response = self.provider.complete(request)
                parsed = parse_translation_response(
                    response.content,
                    pending,
                    allow_terminology_decisions=self.allow_terminology_decisions,
                )
            except TransientProviderError as error:
                transient_failure = str(error)
                if attempt < self.retries and budget[0] > 0:
                    delay = min(8.0, 0.5 * (2**attempt)) + self.random_source.uniform(0, 0.25)
                    self.sleep(delay)
                continue
            except (ProtectionError, ProviderError, ValidationError) as error:
                transient_failure = None
                last_errors = {unit.unit_id: str(error) for unit in pending}
                feedback = f"The previous response was rejected: {error}"
                continue

            transient_failure = None
            outcome.accepted.update(parsed.accepted)
            if parsed.accepted:
                self.on_partial(parsed.accepted)
            outcome.terminology_decisions.extend(parsed.terminology_decisions)
            last_errors = parsed.errors
            pending = tuple(unit for unit in pending if unit.unit_id not in parsed.accepted)
            if not pending:
                return
            feedback = self._feedback(last_errors)

        if not pending:
            return
        if transient_failure is not None:
            for unit in pending:
                outcome.failures[unit.unit_id] = transient_failure
            return
        if len(pending) == 1 or budget[0] <= 0:
            for unit in pending:
                outcome.failures[unit.unit_id] = last_errors.get(
                    unit.unit_id, "deterministic validation failed"
                )
            return
        midpoint = len(pending) // 2
        self._resolve_subset(pending[:midpoint], outcome, budget)
        self._resolve_subset(pending[midpoint:], outcome, budget)

    @staticmethod
    def _feedback(errors: dict[str, str]) -> str:
        first_id = sorted(errors)[0]
        detail = errors[first_id]
        return (
            f"The previous response failed for {first_id}: {detail}. Return all requested IDs. "
            "Return every protected token exactly once; independent tokens may move, while paired "
            "markup must remain balanced and nested."
        )


class ReviewRecovery:
    def __init__(
        self,
        *,
        provider: Provider,
        model: str,
        project_context: str,
        retries: int,
        on_partial: Callable[[dict[str, AcceptedTranslation]], None] | None = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self.provider = provider
        self.model = model
        self.project_context = project_context
        self.retries = retries
        self.on_partial = on_partial or (lambda _: None)
        self.sleep = sleep

    def resolve(
        self,
        units: tuple[TranslationUnit, ...],
        current: dict[str, object],
    ) -> BatchOutcome:
        from localization.models import AcceptedTranslation

        typed_current = {
            unit_id: result
            for unit_id, result in current.items()
            if isinstance(result, AcceptedTranslation)
        }
        if set(typed_current) != {unit.unit_id for unit in units}:
            raise ValidationError("Review requires a current translation for every requested unit")
        outcome = BatchOutcome()
        budget = [max(self.retries + 1, min(128, (self.retries + 1) * (2 * len(units) - 1)))]
        starting_budget = budget[0]
        self._resolve_subset(units, typed_current, outcome, budget)
        outcome.request_count = starting_budget - budget[0]
        for unit in units:
            if unit.unit_id not in outcome.accepted and unit.unit_id not in outcome.failures:
                outcome.failures[unit.unit_id] = "shared root-batch request budget exhausted"
        return outcome

    def _resolve_subset(
        self,
        units: tuple[TranslationUnit, ...],
        current: dict[str, object],
        outcome: BatchOutcome,
        budget: list[int],
    ) -> None:
        from localization.models import AcceptedTranslation

        if not units or budget[0] <= 0:
            return
        subset_current = {
            unit.unit_id: current[unit.unit_id]
            for unit in units
            if isinstance(current[unit.unit_id], AcceptedTranslation)
        }
        last_error = "review validation failed"
        transient = False
        for attempt in range(self.retries + 1):
            if budget[0] <= 0:
                break
            budget[0] -= 1
            request = make_request(
                operation="review",
                schema_name="soulash_review",
                schema=review_schema(units),
                messages=review_messages(
                    units,
                    {unit_id: item.protected_text for unit_id, item in subset_current.items()},
                    project_context=self.project_context,
                ),
                model=self.model,
            )
            try:
                response = self.provider.complete(request)
                accepted, _ = parse_review_response(response.content, units, subset_current)
            except TransientProviderError as error:
                last_error = str(error)
                transient = True
                if attempt < self.retries:
                    self.sleep(min(8.0, 0.5 * (2**attempt)))
                continue
            except (ProtectionError, ProviderError, ValidationError) as error:
                last_error = str(error)
                transient = False
                continue
            outcome.accepted.update(accepted)
            self.on_partial(accepted)
            return
        if transient or len(units) == 1 or budget[0] <= 0:
            for unit in units:
                outcome.failures[unit.unit_id] = last_error
            return
        midpoint = len(units) // 2
        self._resolve_subset(units[:midpoint], current, outcome, budget)
        self._resolve_subset(units[midpoint:], current, outcome, budget)
