from __future__ import annotations

import hashlib
import json
import sqlite3
from datetime import UTC, datetime
from pathlib import Path

from localization.errors import ProtectionError
from localization.models import AcceptedTranslation, GenerationSpec, TranslationUnit
from localization.protection import restore_text


def _now() -> str:
    return datetime.now(UTC).isoformat()


def protected_source_fingerprint(unit: TranslationUnit) -> str:
    payload = {
        "source": unit.source_text,
        "protected": unit.protected.text,
        "revision": unit.protected.revision,
        "tokens": [
            {
                "placeholder": token.placeholder,
                "raw_value": token.raw_value,
                "category": token.category.value,
                "type": token.token_type,
                "group": token.group,
                "role": token.role,
            }
            for token in unit.protected.tokens
        ],
    }
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


class CheckpointStore:
    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.connection = sqlite3.connect(path)
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA journal_mode=WAL")
        self.connection.execute("PRAGMA foreign_keys=ON")
        self.connection.execute("PRAGMA synchronous=FULL")
        self._create_schema()

    def __enter__(self) -> CheckpointStore:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def close(self) -> None:
        self.connection.close()

    def _create_schema(self) -> None:
        self.connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS generations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mode TEXT NOT NULL,
                source_manifest TEXT NOT NULL,
                target_language TEXT NOT NULL,
                project_profile_fingerprint TEXT NOT NULL,
                policy_revision TEXT NOT NULL,
                protection_revision TEXT NOT NULL,
                backend_fingerprint TEXT NOT NULL,
                base_generation_id INTEGER,
                staging_path TEXT,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(base_generation_id) REFERENCES generations(id)
            );
            CREATE TABLE IF NOT EXISTS accepted_results (
                generation_id INTEGER NOT NULL,
                unit_id TEXT NOT NULL,
                protected_source_fingerprint TEXT NOT NULL,
                protected_text TEXT NOT NULL,
                restored_text TEXT NOT NULL,
                grammatical_gender TEXT,
                accepted_at TEXT NOT NULL,
                PRIMARY KEY(generation_id, unit_id),
                FOREIGN KEY(generation_id) REFERENCES generations(id)
            );
            CREATE INDEX IF NOT EXISTS generation_compatibility
                ON generations(mode, source_manifest, target_language, status);
            """
        )
        self.connection.commit()

    def open_generation(self, spec: GenerationSpec, *, resume: bool) -> tuple[int, bool]:
        if resume:
            row = self.connection.execute(
                """
                SELECT id FROM generations
                WHERE mode = ? AND source_manifest = ? AND target_language = ?
                  AND project_profile_fingerprint = ? AND policy_revision = ?
                  AND protection_revision = ? AND backend_fingerprint = ?
                  AND base_generation_id IS ?
                  AND status IN ('active', 'failed', 'complete', 'published')
                ORDER BY id DESC LIMIT 1
                """,
                (
                    spec.mode,
                    spec.source_manifest,
                    spec.target_language,
                    spec.project_profile_fingerprint,
                    spec.policy_revision,
                    spec.protection_revision,
                    spec.backend_fingerprint,
                    spec.base_generation_id,
                ),
            ).fetchone()
            if row is not None:
                generation_id = int(row["id"])
                self.connection.execute(
                    "UPDATE generations SET status = 'active', updated_at = ? WHERE id = ?",
                    (_now(), generation_id),
                )
                self.connection.commit()
                return generation_id, True
        timestamp = _now()
        cursor = self.connection.execute(
            """
            INSERT INTO generations (
                mode, source_manifest, target_language, project_profile_fingerprint,
                policy_revision, protection_revision, backend_fingerprint,
                base_generation_id, staging_path, status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)
            """,
            (
                spec.mode,
                spec.source_manifest,
                spec.target_language,
                spec.project_profile_fingerprint,
                spec.policy_revision,
                spec.protection_revision,
                spec.backend_fingerprint,
                spec.base_generation_id,
                spec.staging_path,
                timestamp,
                timestamp,
            ),
        )
        self.connection.commit()
        return int(cursor.lastrowid), False

    def commit_accepted(
        self,
        generation_id: int,
        units_by_id: dict[str, TranslationUnit],
        accepted: dict[str, AcceptedTranslation],
    ) -> None:
        timestamp = _now()
        rows = []
        for unit_id, result in accepted.items():
            unit = units_by_id[unit_id]
            rows.append(
                (
                    generation_id,
                    unit_id,
                    protected_source_fingerprint(unit),
                    result.protected_text,
                    result.restored_text,
                    result.grammatical_gender,
                    timestamp,
                )
            )
        with self.connection:
            self.connection.executemany(
                """
                INSERT INTO accepted_results (
                    generation_id, unit_id, protected_source_fingerprint, protected_text,
                    restored_text, grammatical_gender, accepted_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(generation_id, unit_id) DO UPDATE SET
                    protected_source_fingerprint = excluded.protected_source_fingerprint,
                    protected_text = excluded.protected_text,
                    restored_text = excluded.restored_text,
                    grammatical_gender = excluded.grammatical_gender,
                    accepted_at = excluded.accepted_at
                """,
                rows,
            )
            self.connection.execute(
                "UPDATE generations SET updated_at = ? WHERE id = ?",
                (timestamp, generation_id),
            )

    def load_compatible(
        self, generation_id: int, units: list[TranslationUnit]
    ) -> dict[str, AcceptedTranslation]:
        units_by_id = {unit.unit_id: unit for unit in units}
        accepted: dict[str, AcceptedTranslation] = {}
        rows = self.connection.execute(
            "SELECT * FROM accepted_results WHERE generation_id = ?", (generation_id,)
        )
        for row in rows:
            unit = units_by_id.get(row["unit_id"])
            if unit is None or row["protected_source_fingerprint"] != protected_source_fingerprint(
                unit
            ):
                continue
            try:
                restored_text = restore_text(unit.protected, row["protected_text"])
            except ProtectionError:
                continue
            if restored_text != row["restored_text"]:
                continue
            accepted[unit.unit_id] = AcceptedTranslation(
                unit_id=unit.unit_id,
                protected_text=row["protected_text"],
                restored_text=restored_text,
                grammatical_gender=row["grammatical_gender"],
            )
        return accepted

    def set_status(self, generation_id: int, status: str) -> None:
        if status not in {"active", "failed", "complete", "published"}:
            raise ValueError(f"Invalid generation status: {status}")
        self.connection.execute(
            "UPDATE generations SET status = ?, updated_at = ? WHERE id = ?",
            (status, _now(), generation_id),
        )
        self.connection.commit()

    def latest_complete_generation(
        self, *, source_manifest: str, target_language: str
    ) -> int | None:
        row = self.connection.execute(
            """
            SELECT id FROM generations
            WHERE source_manifest = ? AND target_language = ?
              AND status IN ('complete', 'published')
            ORDER BY id DESC LIMIT 1
            """,
            (source_manifest, target_language),
        ).fetchone()
        return int(row["id"]) if row is not None else None

    def generation_count(self) -> int:
        return int(self.connection.execute("SELECT COUNT(*) FROM generations").fetchone()[0])
