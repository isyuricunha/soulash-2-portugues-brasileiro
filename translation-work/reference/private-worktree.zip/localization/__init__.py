"""Safe Soulash 2 localization toolkit."""

__version__ = "0.1.0"
