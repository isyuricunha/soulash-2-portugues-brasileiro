from __future__ import annotations

import json
import threading
import urllib.error
import urllib.request
from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any, Protocol

from localization.config import ProviderConfig
from localization.errors import (
    OutputBudgetError,
    ProviderContractError,
    TransientProviderError,
)
from localization.models import ProviderRequest, ProviderResponse


class Provider(Protocol):
    def complete(self, request: ProviderRequest) -> ProviderResponse: ...


class OpenAICompatibleProvider:
    """Minimal Chat Completions adapter with strict operation-specific JSON Schema."""

    def __init__(self, config: ProviderConfig) -> None:
        self.config = config

    @property
    def endpoint(self) -> str:
        base = self.config.base_url.rstrip("/")
        if base.endswith("/chat/completions"):
            return base
        return f"{base}/chat/completions"

    def complete(self, request: ProviderRequest) -> ProviderResponse:
        payload = {
            "model": request.model,
            "messages": list(request.messages),
            "response_format": {
                "type": "json_schema",
                "json_schema": {
                    "name": request.schema_name,
                    "strict": True,
                    "schema": request.schema,
                },
            },
        }
        encoded = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        http_request = urllib.request.Request(
            self.endpoint,
            data=encoded,
            headers={
                "Authorization": f"Bearer {self.config.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(http_request, timeout=self.config.timeout) as response:
                raw = response.read(self.config.max_response_size * 8 + 1)
        except urllib.error.HTTPError as error:
            body = error.read(2_000).decode("utf-8", errors="replace")
            if error.code in {408, 409, 425, 429} or 500 <= error.code <= 599:
                raise TransientProviderError(f"Provider HTTP {error.code}: {body}") from error
            raise ProviderContractError(f"Provider HTTP {error.code}: {body}") from error
        except (urllib.error.URLError, TimeoutError) as error:
            raise TransientProviderError(f"Provider transport failure: {error}") from error
        if len(raw) > self.config.max_response_size * 8:
            raise OutputBudgetError("Provider response exceeded the configured local safety limit")
        try:
            envelope = json.loads(raw.decode("utf-8"))
            choice = envelope["choices"][0]
            message = choice["message"]
            content = message["content"]
            finish_reason = choice.get("finish_reason")
        except (UnicodeDecodeError, json.JSONDecodeError, KeyError, IndexError, TypeError) as error:
            raise ProviderContractError("Invalid Chat Completions response envelope") from error
        if finish_reason in {"length", "max_tokens"}:
            raise OutputBudgetError(
                "Provider exhausted the completion budget before returning valid final JSON"
            )
        if not isinstance(content, str) or not content.strip():
            raise ProviderContractError("Provider returned empty final assistant content")
        return ProviderResponse(
            content=content,
            finish_reason=finish_reason if isinstance(finish_reason, str) else None,
            response_id=envelope.get("id") if isinstance(envelope.get("id"), str) else None,
        )

    def diagnostics(self) -> dict[str, str | int | float | bool]:
        return {
            "translation_model": self.config.translation_model,
            "canonical_provider_model": self.config.translation_model,
            "resolved_gateway_route": self.endpoint,
            "glossary_model": self.config.glossary_model,
            "reasoning_configuration": self.config.reasoning_effort,
            "effective_thinking_mode": "provider default; no unverified field sent",
            "reasoning_budget": "provider default",
            "max_response_size": self.config.max_response_size,
            "timeout": self.config.timeout,
            "retries": self.config.retries,
            "bifrost_passthrough": False,
        }


class ProviderCapacity:
    def __init__(self, *, maximum: int, minimum_translation_slots: int) -> None:
        if maximum < 1 or not 0 <= minimum_translation_slots <= maximum:
            raise ValueError("Invalid provider capacity limits")
        self.maximum = maximum
        self.minimum_translation_slots = minimum_translation_slots
        self._condition = threading.Condition()
        self._main_in_flight = 0
        self._glossary_in_flight = 0
        self._main_waiters = 0

    @property
    def in_flight(self) -> int:
        with self._condition:
            return self._main_in_flight + self._glossary_in_flight

    def snapshot(self) -> dict[str, int]:
        with self._condition:
            return {
                "main_in_flight": self._main_in_flight,
                "glossary_in_flight": self._glossary_in_flight,
                "total_in_flight": self._main_in_flight + self._glossary_in_flight,
                "provider_limit": self.maximum,
            }

    def _can_acquire(self, kind: str) -> bool:
        total = self._main_in_flight + self._glossary_in_flight
        if total >= self.maximum:
            return False
        if kind == "main":
            return True
        glossary_limit = self.maximum - self.minimum_translation_slots
        return self._main_waiters == 0 and self._glossary_in_flight < glossary_limit

    @contextmanager
    def slot(self, kind: str) -> Iterator[None]:
        if kind not in {"main", "glossary"}:
            raise ValueError(f"Unknown capacity kind: {kind}")
        with self._condition:
            if kind == "main":
                self._main_waiters += 1
            try:
                self._condition.wait_for(lambda: self._can_acquire(kind))
                if kind == "main":
                    self._main_in_flight += 1
                else:
                    self._glossary_in_flight += 1
            finally:
                if kind == "main":
                    self._main_waiters -= 1
        try:
            yield
        finally:
            with self._condition:
                if kind == "main":
                    self._main_in_flight -= 1
                else:
                    self._glossary_in_flight -= 1
                self._condition.notify_all()


class CapacityLimitedProvider:
    def __init__(self, provider: Provider, capacity: ProviderCapacity, *, kind: str) -> None:
        self.provider = provider
        self.capacity = capacity
        self.kind = kind

    def complete(self, request: ProviderRequest) -> ProviderResponse:
        with self.capacity.slot(self.kind):
            return self.provider.complete(request)


def make_request(
    *,
    operation: str,
    schema_name: str,
    schema: dict[str, Any],
    messages: tuple[dict[str, str], ...],
    model: str,
) -> ProviderRequest:
    return ProviderRequest(
        operation=operation,
        schema_name=schema_name,
        schema=schema,
        messages=messages,
        model=model,
    )
