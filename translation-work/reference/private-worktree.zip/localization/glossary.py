from __future__ import annotations

import json
import re
import sqlite3
import unicodedata
from datetime import UTC, datetime
from pathlib import Path

from localization.errors import ValidationError
from localization.models import GlossaryEntry, TranslationUnit
from localization.provider import Provider, make_request
from localization.schemas import (
    glossary_resolution_schema,
    parse_glossary_resolution_response,
)

GLOSSARY_STATUSES = {
    "locked",
    "confirmed",
    "provisional",
    "challenged",
    "conflicted",
    "preserved",
    "deprecated",
}
WORKER_SIGNALS = {
    "terminology_decision",
    "conflict",
    "inconsistent_target",
    "missing_recurring_term",
    "preserve_localize_inconsistency",
    "manual",
}


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _normalize(text: str) -> str:
    decomposed = unicodedata.normalize("NFKD", text.casefold())
    return " ".join(
        "".join(
            character for character in decomposed if not unicodedata.combining(character)
        ).split()
    )


class GlossaryStore:
    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(path)
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA journal_mode=WAL")
        self.connection.execute("PRAGMA foreign_keys=ON")
        self._create_schema()

    def __enter__(self) -> GlossaryStore:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def close(self) -> None:
        self.connection.close()

    def _create_schema(self) -> None:
        self.connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS metadata (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            INSERT OR IGNORE INTO metadata(key, value) VALUES ('revision', '0');
            CREATE TABLE IF NOT EXISTS entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_term TEXT NOT NULL,
                normalized_source TEXT NOT NULL,
                target_term TEXT NOT NULL,
                scope TEXT NOT NULL,
                status TEXT NOT NULL,
                confidence REAL NOT NULL,
                generation_id INTEGER,
                revision INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                UNIQUE(normalized_source, scope)
            );
            CREATE TABLE IF NOT EXISTS aliases (
                entry_id INTEGER NOT NULL,
                alias TEXT NOT NULL,
                normalized_alias TEXT NOT NULL,
                PRIMARY KEY(entry_id, normalized_alias),
                FOREIGN KEY(entry_id) REFERENCES entries(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS evidence (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entry_id INTEGER NOT NULL,
                unit_id TEXT NOT NULL,
                source_excerpt TEXT NOT NULL,
                target_excerpt TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(entry_id) REFERENCES entries(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS linked_units (
                entry_id INTEGER NOT NULL,
                unit_id TEXT NOT NULL,
                PRIMARY KEY(entry_id, unit_id),
                FOREIGN KEY(entry_id) REFERENCES entries(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                dedupe_key TEXT NOT NULL UNIQUE,
                signal TEXT NOT NULL,
                source_term TEXT NOT NULL,
                candidate_target TEXT,
                scope TEXT NOT NULL,
                evidence_unit_id TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            """
        )
        self.connection.commit()

    @property
    def revision(self) -> int:
        row = self.connection.execute(
            "SELECT value FROM metadata WHERE key = 'revision'"
        ).fetchone()
        return int(row["value"])

    def _next_revision(self) -> int:
        revision = self.revision + 1
        self.connection.execute(
            "UPDATE metadata SET value = ? WHERE key = 'revision'", (str(revision),)
        )
        return revision

    def upsert_entry(
        self,
        *,
        source_term: str,
        target_term: str,
        scope: str,
        status: str,
        confidence: float,
        generation_id: int | None = None,
        aliases: tuple[str, ...] = (),
    ) -> int:
        if status not in GLOSSARY_STATUSES:
            raise ValidationError(f"Invalid glossary status: {status}")
        if not source_term.strip() or not target_term.strip() or not scope.strip():
            raise ValidationError("Glossary terms and scope must be non-empty")
        if not 0 <= confidence <= 1:
            raise ValidationError("Glossary confidence must be between 0 and 1")
        normalized = _normalize(source_term)
        existing = self.connection.execute(
            "SELECT id, status FROM entries WHERE normalized_source = ? AND scope = ?",
            (normalized, scope.strip()),
        ).fetchone()
        if existing is not None and existing["status"] == "locked" and status != "locked":
            raise ValidationError("A locked glossary entry cannot be overwritten")
        timestamp = _now()
        with self.connection:
            revision = self._next_revision()
            self.connection.execute(
                """
                INSERT INTO entries (
                    source_term, normalized_source, target_term, scope, status, confidence,
                    generation_id, revision, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(normalized_source, scope) DO UPDATE SET
                    source_term = excluded.source_term,
                    target_term = excluded.target_term,
                    status = excluded.status,
                    confidence = excluded.confidence,
                    generation_id = excluded.generation_id,
                    revision = excluded.revision,
                    updated_at = excluded.updated_at
                """,
                (
                    source_term.strip(),
                    normalized,
                    target_term.strip(),
                    scope.strip(),
                    status,
                    confidence,
                    generation_id,
                    revision,
                    timestamp,
                    timestamp,
                ),
            )
            entry_id = int(
                self.connection.execute(
                    "SELECT id FROM entries WHERE normalized_source = ? AND scope = ?",
                    (normalized, scope.strip()),
                ).fetchone()["id"]
            )
            for alias in aliases:
                if alias.strip():
                    self.connection.execute(
                        "INSERT OR IGNORE INTO aliases(entry_id, alias, normalized_alias) "
                        "VALUES (?, ?, ?)",
                        (entry_id, alias.strip(), _normalize(alias)),
                    )
        return entry_id

    def relevant(
        self, units: tuple[TranslationUnit, ...], *, limit: int = 30
    ) -> list[GlossaryEntry]:
        haystack = _normalize(" ".join(unit.source_text for unit in units))
        tokens = set(re.findall(r"[\w'-]+", haystack))
        rows = self.connection.execute(
            """
            SELECT e.*, GROUP_CONCAT(a.normalized_alias, '|') AS alias_values
            FROM entries e LEFT JOIN aliases a ON a.entry_id = e.id
            WHERE e.status != 'deprecated'
            GROUP BY e.id
            """
        )
        ranked: list[tuple[int, int, GlossaryEntry]] = []
        for row in rows:
            source = row["normalized_source"]
            aliases = (row["alias_values"] or "").split("|")
            exact = source in haystack or any(alias and alias in haystack for alias in aliases)
            overlap = len(set(source.split()) & tokens)
            globally_locked = row["status"] == "locked" and row["scope"] == "global"
            linked = self.connection.execute(
                "SELECT 1 FROM linked_units WHERE entry_id = ? AND unit_id IN ({}) LIMIT 1".format(
                    ",".join("?" for _ in units) or "NULL"
                ),
                (row["id"], *(unit.unit_id for unit in units)),
            ).fetchone()
            if not exact and not overlap and not globally_locked and linked is None:
                continue
            score = (
                int(exact) * 100
                + overlap * 10
                + int(globally_locked) * 50
                + int(linked is not None) * 25
            )
            entry = GlossaryEntry(
                entry_id=row["id"],
                source_term=row["source_term"],
                target_term=row["target_term"],
                scope=row["scope"],
                status=row["status"],
                confidence=row["confidence"],
                revision=row["revision"],
            )
            ranked.append((score, entry.revision, entry))
        ranked.sort(key=lambda item: (-item[0], -item[1], item[2].entry_id))
        return [item[2] for item in ranked[:limit]]

    def queue_task(
        self,
        *,
        signal: str,
        source_term: str,
        candidate_target: str | None,
        scope: str,
        evidence_unit_id: str,
    ) -> tuple[str, int | None]:
        if signal not in WORKER_SIGNALS:
            return "skipped_no_signal", None
        if not source_term.strip() or not scope.strip() or not evidence_unit_id.strip():
            raise ValidationError("Glossary task evidence fields must be non-empty")
        dedupe_key = "\0".join(
            (signal, _normalize(source_term), _normalize(candidate_target or ""), scope.strip())
        )
        timestamp = _now()
        with self.connection:
            self.connection.execute(
                """
                INSERT OR IGNORE INTO tasks (
                    dedupe_key, signal, source_term, candidate_target, scope,
                    evidence_unit_id, status, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?)
                """,
                (
                    dedupe_key,
                    signal,
                    source_term.strip(),
                    candidate_target.strip() if candidate_target else None,
                    scope.strip(),
                    evidence_unit_id.strip(),
                    timestamp,
                    timestamp,
                ),
            )
            row = self.connection.execute(
                "SELECT id FROM tasks WHERE dedupe_key = ?", (dedupe_key,)
            ).fetchone()
        return "queued", int(row["id"])

    def pending_tasks(self, *, limit: int) -> list[dict[str, object]]:
        rows = self.connection.execute(
            "SELECT * FROM tasks WHERE status = 'pending' ORDER BY id LIMIT ?", (limit,)
        )
        return [dict(row) for row in rows]

    def pending_task_count(self) -> int:
        return int(
            self.connection.execute(
                "SELECT COUNT(*) FROM tasks WHERE status = 'pending'"
            ).fetchone()[0]
        )

    def complete_task(self, task_id: int) -> None:
        self.connection.execute(
            "UPDATE tasks SET status = 'complete', updated_at = ? WHERE id = ?",
            (_now(), task_id),
        )
        self.connection.commit()


class GlossaryWorker:
    def __init__(self, *, provider: Provider, model: str, project_context: str) -> None:
        self.provider = provider
        self.model = model
        self.project_context = project_context

    def run_once(self, store: GlossaryStore, *, limit: int = 8) -> int:
        tasks = store.pending_tasks(limit=limit)
        if not tasks:
            return 0
        candidate_ids = tuple(int(task["id"]) for task in tasks)
        payload = {
            "operation": "resolve_glossary_candidates",
            "project_context": self.project_context,
            "candidates": tasks,
            "rule": (
                "Resolve only the supplied recurring term candidates or conflicts. "
                "Return final contract JSON only."
            ),
        }
        request = make_request(
            operation="glossary",
            schema_name="soulash_glossary_resolution",
            schema=glossary_resolution_schema(candidate_ids),
            messages=(
                {
                    "role": "system",
                    "content": (
                        "You resolve bounded PT-BR game terminology candidates. Return only "
                        "the final JSON contract without Markdown, prose, or reasoning traces."
                    ),
                },
                {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
            ),
            model=self.model,
        )
        response = self.provider.complete(request)
        resolutions = parse_glossary_resolution_response(response.content, candidate_ids)
        tasks_by_id = {int(task["id"]): task for task in tasks}
        for resolution in resolutions:
            task_id = int(resolution["candidate_id"])
            task = tasks_by_id[task_id]
            store.upsert_entry(
                source_term=str(task["source_term"]),
                target_term=str(resolution["target_term"]),
                scope=str(task["scope"]),
                status=str(resolution["status"]),
                confidence=0.8,
            )
            store.complete_task(task_id)
        return len(resolutions)
