class LocalizationError(Exception):
    """Base error for expected localization failures."""


class ConfigurationError(LocalizationError):
    """Raised when runtime configuration is incomplete or unsafe."""


class FormatError(LocalizationError):
    """Raised when a source or target file cannot be handled losslessly."""


class ProtectionError(LocalizationError):
    """Raised when protected content is malformed or damaged."""


class ValidationError(LocalizationError):
    """Raised when translated output violates a project invariant."""


class ProviderError(LocalizationError):
    """Base error for provider transport or response failures."""


class TransientProviderError(ProviderError):
    """Raised for retryable transport, timeout, rate-limit, or service failures."""


class ProviderContractError(ProviderError):
    """Raised when a provider rejects or violates the configured request contract."""


class OutputBudgetError(ProviderError):
    """Raised when a provider exhausts its completion budget before valid final output."""
