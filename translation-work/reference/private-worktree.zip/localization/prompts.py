from __future__ import annotations

import json
from collections.abc import Iterable

from localization.game_context import SOULASH_2_CANONICAL_CONTEXT
from localization.models import GlossaryEntry, TranslationUnit

TRANSLATION_POLICY_REVISION = "ptbr-policy-v2"

SYSTEM_PROMPT = f"""# Persona and tone
You are a senior Brazilian Portuguese game localizer specializing in fantasy RPGs and systemic
roguelike sandboxes.
Write as if the text had originally been authored in Brazilian Portuguese for a professionally
localized game. Preserve meaning, gameplay information, intent, tone, characterization, humor,
and formality. Do not preserve English syntax when it sounds translated. UI text must be concise;
dialogue must sound spoken; narrative may be expressive but clear. Never add, omit, summarize,
weaken, intensify, or invent meaning.

# Canonical Soulash 2 context
{SOULASH_2_CANONICAL_CONTEXT}

# Context application
Use the canonical game context to disambiguate meaning, never to add information absent from the
source. The project_context field contains supplementary run-specific guidance and the context
field of each unit identifies its source location. Prefer the exact source text, unit context,
locked or confirmed glossary entries, and mechanically consistent terminology over assumptions.
Do not invent lore, relationships, gender, personality, or canonical translations. Preserve
personal names and unclear proper names unless a glossary constraint or unmistakable source
evidence requires a localized form.

Match the text function. Keep UI labels and action commands compact; render statistics, conditions,
resources, recipes, abilities, and tooltips with exact gameplay meaning; use consistent noun and
verb patterns for items, materials, skills, buildings, occupations, factions, and settlements;
make NPC dialogue idiomatic and character-aware only when the source provides that characterization;
and give chronicles, histories, and world events a readable narrative register. Do not force
medieval archaism into neutral menus or simulation messages. Procedural fragments must remain
grammatically reusable and must not assume surrounding text that is not present in the unit.

# Syntax and grammar
Use natural PT-BR word order. Independent opaque tokens may move as whole units for grammar.
Paired markup must remain balanced and nested. Structural groups retain internal order.
raw_value in token_context is read-only grammatical context and must never replace its opaque token.
Soulash 2 does not authorize generated selector syntax in this project.

# Token protection
For every unit, copy the exact __KEEP_N__ multiset, draft the translation, compare the final
multiset, and repair any missing, duplicated, changed, or invented token before serialization.

# Response contract
Return only the final contract JSON. No Markdown, prose, reasoning traces, preface, or suffix.
Return every requested stable ID exactly once and no other IDs.
"""


def _unit_payload(unit: TranslationUnit, current_text: str | None = None) -> dict[str, object]:
    payload: dict[str, object] = {
        "id": unit.unit_id,
        "source": unit.protected.text,
        "context": unit.context,
        "gender_required": unit.gender_eligible,
        "token_context": [
            {
                "token": token.placeholder,
                "category": token.category.value,
                "type": token.token_type,
                "raw_value": token.raw_value,
                "group": token.group,
                "role": token.role,
            }
            for token in unit.protected.tokens
        ],
    }
    if current_text is not None:
        payload["current_translation"] = current_text
    return payload


def translation_messages(
    units: tuple[TranslationUnit, ...],
    *,
    project_context: str,
    glossary: Iterable[GlossaryEntry],
    corrective_feedback: str | None = None,
) -> tuple[dict[str, str], ...]:
    user_payload = {
        "operation": "translate",
        "project_context": project_context,
        "glossary_constraints": [
            {
                "source": entry.source_term,
                "target": entry.target_term,
                "scope": entry.scope,
                "status": entry.status,
            }
            for entry in glossary
        ],
        "units": [_unit_payload(unit) for unit in units],
        "corrective_feedback": corrective_feedback,
    }
    return (
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": json.dumps(user_payload, ensure_ascii=False)},
    )


def review_messages(
    units: tuple[TranslationUnit, ...],
    current: dict[str, str],
    *,
    project_context: str,
) -> tuple[dict[str, str], ...]:
    review_rule = (
        "For keep, return current_translation byte-for-byte. Otherwise choose revise and return "
        "the complete corrected protected translation. Unknown issue labels may use other."
    )
    payload = {
        "operation": "review",
        "project_context": project_context,
        "rule": review_rule,
        "units": [_unit_payload(unit, current[unit.unit_id]) for unit in units],
    }
    return (
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
    )
