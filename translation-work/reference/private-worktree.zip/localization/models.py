from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import Any, TypeAlias

JsonValue: TypeAlias = dict[str, "JsonValue"] | list["JsonValue"] | str | int | float | bool | None
JsonPointer: TypeAlias = tuple[str | int, ...]


class TokenCategory(StrEnum):
    INDEPENDENT = "independent"
    PAIRED_STRUCTURAL = "paired_structural"
    GROUP_STRUCTURAL = "group_structural"
    FIXED_POSITION = "fixed_position"


@dataclass(frozen=True, slots=True)
class ProtectedToken:
    placeholder: str
    raw_value: str
    category: TokenCategory
    token_type: str
    group: str | None = None
    role: str | None = None


@dataclass(frozen=True, slots=True)
class ProtectedText:
    text: str
    tokens: tuple[ProtectedToken, ...]
    revision: str


@dataclass(frozen=True, slots=True)
class TranslationUnit:
    unit_id: str
    relative_path: str
    pointer: JsonPointer
    stable_path: str
    source_text: str
    protected: ProtectedText
    context: str
    output_pointer: JsonPointer | None = None
    synthetic: bool = False
    gender_eligible: bool = False

    @property
    def destination_pointer(self) -> JsonPointer:
        return self.output_pointer or self.pointer


@dataclass(slots=True)
class ParsedFile:
    relative_path: str
    source_path: Path
    kind: str
    data: JsonValue | None = None
    raw_bytes: bytes | None = None


@dataclass(slots=True)
class SourceProject:
    root: Path
    files: dict[str, ParsedFile]
    units: list[TranslationUnit]
    manifest_hash: str


@dataclass(frozen=True, slots=True)
class AcceptedTranslation:
    unit_id: str
    protected_text: str
    restored_text: str
    grammatical_gender: str | None = None


@dataclass(slots=True)
class ReconstructionResult:
    root: Path
    file_count: int
    unit_count: int
    manifest: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ProviderRequest:
    operation: str
    schema_name: str
    schema: dict[str, Any]
    messages: tuple[dict[str, str], ...]
    model: str


@dataclass(frozen=True, slots=True)
class ProviderResponse:
    content: str
    finish_reason: str | None
    response_id: str | None = None


@dataclass(frozen=True, slots=True)
class TranslationBatch:
    batch_id: int
    units: tuple[TranslationUnit, ...]
    character_count: int
    estimated_input_tokens: int
    protected_token_count: int


@dataclass(slots=True)
class BatchOutcome:
    accepted: dict[str, AcceptedTranslation] = field(default_factory=dict)
    failures: dict[str, str] = field(default_factory=dict)
    terminology_decisions: list[dict[str, str]] = field(default_factory=list)
    request_count: int = 0
    duration_seconds: float = 0.0


@dataclass(frozen=True, slots=True)
class GenerationSpec:
    mode: str
    source_manifest: str
    target_language: str
    project_profile_fingerprint: str
    policy_revision: str
    protection_revision: str
    backend_fingerprint: str
    base_generation_id: int | None = None
    staging_path: str | None = None


@dataclass(frozen=True, slots=True)
class GlossaryEntry:
    entry_id: int
    source_term: str
    target_term: str
    scope: str
    status: str
    confidence: float
    revision: int


@dataclass(slots=True)
class PipelineResult:
    mode: str
    generation_id: int
    resumed: bool
    selected_units: int
    reused_units: int
    accepted_units: int
    failures: dict[str, str] = field(default_factory=dict)
    published: bool = False
    output_root: Path | None = None
    previous_output: Path | None = None
    glossary_pending: int = 0
