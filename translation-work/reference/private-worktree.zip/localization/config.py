from __future__ import annotations

import os
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path

from localization.errors import ConfigurationError
from localization.game_context import DEFAULT_PROJECT_CONTEXT

DEFAULT_REASONING_EFFORT = "medium"
DEFAULT_MAX_RESPONSE_SIZE = 32_768
DEFAULT_TIMEOUT = 300.0
DEFAULT_RETRIES = 3
DEFAULT_BATCH_SIZE = 10
DEFAULT_MAX_BATCH_CHARS = 2_000
DEFAULT_TRANSLATION_CONCURRENCY = 5
DEFAULT_PROVIDER_MAX_CONCURRENCY = 5
DEFAULT_MIN_TRANSLATION_SLOTS = 4


def load_dotenv(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    values: dict[str, str] = {}
    for line_number, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise ConfigurationError(f"Invalid .env entry at {path}:{line_number}")
        key, value = line.split("=", 1)
        key = key.strip()
        if not key or not key.replace("_", "").isalnum():
            raise ConfigurationError(f"Invalid .env key at {path}:{line_number}")
        values[key] = value.strip().strip('"').strip("'")
    return values


def _first_nonblank(*values: str | None) -> str | None:
    for value in values:
        if value is not None and value.strip():
            return value.strip()
    return None


@dataclass(frozen=True, slots=True)
class ProviderConfig:
    api_key: str
    base_url: str
    translation_model: str
    glossary_model: str
    reasoning_effort: str = DEFAULT_REASONING_EFFORT
    max_response_size: int = DEFAULT_MAX_RESPONSE_SIZE
    timeout: float = DEFAULT_TIMEOUT
    retries: int = DEFAULT_RETRIES

    @classmethod
    def from_sources(
        cls,
        *,
        cli: Mapping[str, object | None],
        environment: Mapping[str, str] | None = None,
        dotenv_path: Path | None = None,
        require_credentials: bool = True,
    ) -> ProviderConfig:
        dotenv_values = load_dotenv(dotenv_path) if dotenv_path else {}
        process_environment = dict(environment if environment is not None else os.environ)

        def env(name: str) -> str | None:
            return _first_nonblank(process_environment.get(name), dotenv_values.get(name))

        api_key = env("API_KEY") or ""
        base_url = env("TRANSLATION_BASE_URL") or ""
        translation_model = env("TRANSLATION_MODEL") or ""
        glossary_model = env("GLOSSARY_MODEL") or translation_model
        reasoning_effort = _first_nonblank(
            str(cli["reasoning_effort"]) if cli.get("reasoning_effort") else None,
            env("TRANSLATION_REASONING_EFFORT"),
            DEFAULT_REASONING_EFFORT,
        )
        max_response_size = int(
            cli["max_response_size"]
            if cli.get("max_response_size") is not None
            else DEFAULT_MAX_RESPONSE_SIZE
        )
        timeout = float(cli["timeout"] if cli.get("timeout") is not None else DEFAULT_TIMEOUT)
        retries = int(cli["retries"] if cli.get("retries") is not None else DEFAULT_RETRIES)
        if require_credentials and not all((api_key, base_url, translation_model)):
            raise ConfigurationError(
                "API_KEY, TRANSLATION_BASE_URL, and TRANSLATION_MODEL are required for a live run"
            )
        if max_response_size <= 0 or timeout <= 0 or retries < 0:
            raise ConfigurationError(
                "Provider budgets and timeout must be positive; retries cannot be negative"
            )
        return cls(
            api_key=api_key,
            base_url=base_url.rstrip("/"),
            translation_model=translation_model,
            glossary_model=glossary_model,
            reasoning_effort=reasoning_effort or DEFAULT_REASONING_EFFORT,
            max_response_size=max_response_size,
            timeout=timeout,
            retries=retries,
        )


@dataclass(frozen=True, slots=True)
class RunConfig:
    repository_root: Path
    input_root: Path
    output_root: Path
    state_root: Path
    source_language: str = "en"
    target_language: str = "pt-BR"
    project_context: str = DEFAULT_PROJECT_CONTEXT

    def validate_paths(self) -> None:
        input_path = self.input_root.resolve()
        output_path = self.output_root.resolve()
        if input_path == output_path:
            raise ConfigurationError("Input and output paths must be different")
