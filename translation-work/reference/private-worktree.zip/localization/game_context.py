from __future__ import annotations

SOULASH_2_CANONICAL_CONTEXT = """Soulash 2 is a single-player fantasy sandbox RPG that blends
traditional roguelike, role-playing, simulation, and strategy elements. It takes place in a realm
where the gods have perished and power, conquest, destruction, and ascension to a divine throne
are central themes. The player acts through an individual character but can shape an entire
procedurally generated open world and the history that continues around that character.

Each world has a simulated past and living settlements influenced by civilizations, trade routes,
resource extraction, food consumption, occupations, wages, families, character lifecycles, and
war. Supported playstyles include exploration, turn-based combat, crafting with chosen materials
and magical ingredients, trading, theft, farming, construction, settlement leadership, conquest,
and founding a family whose descendants can inherit the player's legacy. Mortality ranges from
resurrection with penalties to persistent-world character death and full roguelike permadeath.

The setting is dark fantasy, but not every string should sound archaic, ominous, or grandiose.
System text, economy, crafting, construction, and settlement interfaces must remain direct and
mechanically precise. Dialogue should sound natural for the speaker and immediate situation.
Historical or world-event prose may carry more weight, while still remaining clear in Brazilian
Portuguese. Humor should be preserved when present in the source, never added merely because the
world is grim."""

DEFAULT_PROJECT_CONTEXT = (
    "Translate the current English Soulash 2 source snapshot. Treat per-unit structural context "
    "and accepted glossary decisions as authoritative supplementary evidence."
)
