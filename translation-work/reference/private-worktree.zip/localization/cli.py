from __future__ import annotations

import argparse
from collections.abc import Sequence
from pathlib import Path

from localization import __version__
from localization.batching import AdaptiveBatcher
from localization.config import (
    DEFAULT_BATCH_SIZE,
    DEFAULT_MAX_BATCH_CHARS,
    DEFAULT_MIN_TRANSLATION_SLOTS,
    DEFAULT_PROVIDER_MAX_CONCURRENCY,
    DEFAULT_TRANSLATION_CONCURRENCY,
    ProviderConfig,
    RunConfig,
)
from localization.errors import ConfigurationError, LocalizationError
from localization.formats import SoulashFormatHandler
from localization.game_context import DEFAULT_PROJECT_CONTEXT
from localization.pipeline import LocalizationPipeline, PipelineSettings
from localization.progress import LiveProgressReporter
from localization.protection import protect_text, restore_text
from localization.provider import (
    CapacityLimitedProvider,
    OpenAICompatibleProvider,
    ProviderCapacity,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Safe Soulash 2 Brazilian Portuguese localization toolkit"
    )
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--review", action="store_true", help="review a complete base generation")
    mode.add_argument("--remake", action="store_true", help="retranslate every source unit")
    parser.add_argument("--version", action="version", version=__version__)
    parser.add_argument(
        "--refresh-source",
        type=Path,
        metavar="CORE_2",
        help="create a guarded EN snapshot from a Soulash 2 core_2 directory",
    )
    parser.add_argument("--input", type=Path, default=Path("EN/translations/ptbr"))
    parser.add_argument("--output", type=Path, default=Path("PTBR"))
    parser.add_argument("--format", choices=("soulash2",), default="soulash2")
    parser.add_argument("--source-lang", choices=("en",), default="en")
    parser.add_argument("--target-lang", choices=("pt-BR",), default="pt-BR")
    parser.add_argument(
        "--project-context",
        default=DEFAULT_PROJECT_CONTEXT,
        help="add run-specific guidance to the canonical Soulash 2 system context",
    )
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--validate-only", action="store_true")
    parser.add_argument("--resume", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument(
        "--batch-size",
        type=int,
        default=DEFAULT_BATCH_SIZE,
        help=f"set the maximum units per batch (default: {DEFAULT_BATCH_SIZE})",
    )
    parser.add_argument(
        "--max-batch-chars",
        type=int,
        default=DEFAULT_MAX_BATCH_CHARS,
        help=(
            "set the maximum source-plus-unit-context characters per batch "
            f"(default: {DEFAULT_MAX_BATCH_CHARS})"
        ),
    )
    parser.add_argument("--max-response-size", type=int)
    parser.add_argument("--reasoning-effort")
    parser.add_argument("--timeout", type=float)
    parser.add_argument("--retries", type=int)
    parser.add_argument(
        "--translation-concurrency", type=int, default=DEFAULT_TRANSLATION_CONCURRENCY
    )
    parser.add_argument(
        "--provider-max-concurrency", type=int, default=DEFAULT_PROVIDER_MAX_CONCURRENCY
    )
    parser.add_argument("--min-translation-slots", type=int, default=DEFAULT_MIN_TRANSLATION_SLOTS)
    parser.add_argument("--glossary", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--glossary-worker", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--wait-for-glossary", action="store_true")
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    return parser


def _mode(args: argparse.Namespace) -> str:
    if args.review:
        return "review"
    if args.remake:
        return "remake"
    return "normal"


def _validate_runtime_options(args: argparse.Namespace) -> None:
    positive = {
        "batch size": args.batch_size,
        "maximum batch characters": args.max_batch_chars,
        "translation concurrency": args.translation_concurrency,
        "provider maximum concurrency": args.provider_max_concurrency,
    }
    invalid = [name for name, value in positive.items() if value < 1]
    if invalid:
        raise ConfigurationError(f"These runtime limits must be positive: {', '.join(invalid)}")
    if not 0 <= args.min_translation_slots <= args.provider_max_concurrency:
        raise ConfigurationError("min-translation-slots must fit provider-max-concurrency")
    if args.translation_concurrency > args.provider_max_concurrency:
        raise ConfigurationError("translation-concurrency cannot exceed provider-max-concurrency")
    if not args.glossary:
        args.glossary_worker = False
    if args.wait_for_glossary and not args.glossary_worker:
        raise ConfigurationError("wait-for-glossary requires glossary-worker")


def _print_diagnostics(provider: OpenAICompatibleProvider, args: argparse.Namespace) -> None:
    diagnostics = provider.diagnostics()
    diagnostics.update(
        {
            "batch_size": args.batch_size,
            "maximum_batch_characters": args.max_batch_chars,
            "translation_concurrency": args.translation_concurrency,
            "provider_max_concurrency": args.provider_max_concurrency,
            "minimum_translation_slots": args.min_translation_slots,
        }
    )
    print("Effective provider configuration:")
    for key, value in diagnostics.items():
        print(f"  {key}={value}")


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    handler = SoulashFormatHandler()
    try:
        _validate_runtime_options(args)
        if args.refresh_source:
            manifest = handler.refresh_source(args.refresh_source, Path("EN"))
            print(
                f"Source snapshot created: files={len(manifest['files'])}, "
                f"units={manifest['units']}, path={Path('EN').resolve()}"
            )
            return 0
        if args.self_test:
            sample = protect_text("Deal ::damage damage [color=1,2,3,4]now[/color].")
            restore_text(sample, sample.text)
            print("Self-test passed")
            return 0

        run_config = RunConfig(
            repository_root=Path.cwd(),
            input_root=args.input,
            output_root=args.output,
            state_root=Path(".localization-state"),
            source_language=args.source_lang,
            target_language=args.target_lang,
            project_context=args.project_context,
        )
        run_config.validate_paths()
        project = handler.load(run_config.input_root)
        if args.validate_only:
            validation = handler.validate_published(project, run_config.output_root)
            print(
                f"Published target valid: files={len(validation['files'])}, "
                f"units={validation['units']}, path={run_config.output_root.resolve()}"
            )
            return 0
        if args.dry_run:
            batches = AdaptiveBatcher(
                maximum_units=args.batch_size,
                maximum_characters=args.max_batch_chars,
            ).create_batches(project.units)
            print(
                f"Dry run valid: files={len(project.files)}, units={len(project.units)}, "
                f"batches={len(batches)}, manifest={project.manifest_hash}"
            )
            return 0

        provider_config = ProviderConfig.from_sources(
            cli=vars(args),
            dotenv_path=run_config.repository_root / ".env",
        )
        base_provider = OpenAICompatibleProvider(provider_config)
        _print_diagnostics(base_provider, args)
        capacity = ProviderCapacity(
            maximum=args.provider_max_concurrency,
            minimum_translation_slots=args.min_translation_slots,
        )
        translation_provider = CapacityLimitedProvider(base_provider, capacity, kind="main")
        glossary_provider = CapacityLimitedProvider(base_provider, capacity, kind="glossary")

        progress_reporter = LiveProgressReporter(verbose=args.verbose)
        pipeline = LocalizationPipeline(
            handler=handler,
            translation_provider=translation_provider,
            glossary_provider=glossary_provider,
            progress=progress_reporter,
        )
        try:
            result = pipeline.run(
                project,
                PipelineSettings(
                    mode=_mode(args),
                    target_language=args.target_lang,
                    project_context=args.project_context,
                    model=provider_config.translation_model,
                    glossary_model=provider_config.glossary_model,
                    backend_fingerprint=(
                        f"{provider_config.base_url}|{provider_config.translation_model}"
                    ),
                    output_root=run_config.output_root,
                    state_root=run_config.state_root,
                    resume=args.resume,
                    batch_size=args.batch_size,
                    maximum_batch_characters=args.max_batch_chars,
                    retries=provider_config.retries,
                    translation_concurrency=args.translation_concurrency,
                    glossary_enabled=args.glossary,
                    glossary_worker_enabled=args.glossary_worker,
                    wait_for_glossary=args.wait_for_glossary,
                ),
            )
        finally:
            progress_reporter.finish()
        if result.failures:
            print(
                f"Translation failed: generation={result.generation_id}, "
                f"accepted={result.accepted_units}, failed={len(result.failures)}"
            )
            for unit_id, reason in sorted(result.failures.items()):
                print(f"  {unit_id}: {reason}")
            return 1
        print(
            f"Translation published: mode={result.mode}, generation={result.generation_id}, "
            f"accepted={result.accepted_units}, reused={result.reused_units}, "
            f"glossary_pending={result.glossary_pending}, output={result.output_root}"
        )
        if result.previous_output:
            print(f"Previous valid output preserved: {result.previous_output}")
        return 0
    except LocalizationError as error:
        print(f"ERROR: {error}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
