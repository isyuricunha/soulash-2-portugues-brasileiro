# Soulash 2 Brazilian Portuguese Localization Toolkit

This repository rebuilds the Brazilian Portuguese localization of Soulash 2 from the current
English game data. It starts from a fresh source snapshot and does not reuse the old public PT-BR
translation or its text cache.

The checked source snapshot was extracted from Soulash 2 `0.10.1`. It contains 5,752 files and
27,829 protected translation units. Its source manifest is
`3ad5a438a85b3468e6cba9b3acb8e240a18812ee9a10cd0d6fc33fc4eb48a14c`.

The provider-backed PT-BR generation completed on 2026-08-19. The published `PTBR` output passes
the full offline validation contract for all 5,752 files and 27,829 translation units.

## Requirements

- Python 3.11 or newer.
- A Chat Completions-compatible gateway that supports strict `json_schema` response formatting.
- One gateway URL, credential, and configured model for a live run.

Runtime code uses only the Python standard library. Ruff is used only for repository validation.
The adapter follows the documented Chat Completions `response_format` contract with
`type=json_schema`, a named schema, and `strict=true`; local validation remains authoritative.
See the [official Chat Completions reference](https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create).

## Repository layout

```text
EN/                         Guarded English source snapshot
  source-manifest.json      Source paths, file hashes, and extraction revision
  translations/ptbr/        Source skeleton mirrored for deployable reconstruction
PTBR/                       Complete copy-ready mod; created only after validation
.localization-state/        Ignored SQLite/WAL checkpoints and glossary
localization/               Typed implementation
tests/                      Fake-provider behavioral tests
translate_project.py        Portable command-line entry point
```

The `ptbr` directory inside `EN` is a structural staging path, not translated content. `EN` is the
source-language root. The final `PTBR` folder mirrors the mod structure expected under Soulash 2's
`data/mods` directory.

## First setup

Create a local `.env` from `.env.example`:

```dotenv
API_KEY=
TRANSLATION_BASE_URL=
TRANSLATION_MODEL=
GLOSSARY_MODEL=
TRANSLATION_REASONING_EFFORT=medium
```

The first three variables are required only for a live provider-backed run. `GLOSSARY_MODEL`
defaults to `TRANSLATION_MODEL`; blank optional values are accepted. `.env` and all durable runtime
state are ignored by Git.

The generic adapter deliberately sends no unverified reasoning, thinking, sampling, or model token
budget fields. `--reasoning-effort` is recorded in diagnostics but is emitted only when a verified
model profile supports it. `--max-response-size` always enforces a local response safety ceiling.

## Safe source refresh

Refreshing refuses to overwrite an existing `EN` snapshot:

```powershell
python translate_project.py --refresh-source "E:\SteamLibrary\steamapps\common\Soulash 2\data\mods\core_2"
```

The installed game is read-only input. The extractor includes the proven JSON and TXT translation
surface, excludes scripts, maps, portraits, animations, asset registries, and technical root
configuration, and copies personal-name TXT files byte-for-byte without sending them to a provider.

## Offline validation

These commands never contact the production provider:

```powershell
python translate_project.py --self-test
python translate_project.py --dry-run --input EN\translations\ptbr
python translate_project.py --validate-only --input EN\translations\ptbr --output PTBR
python -m unittest discover -s tests -v
python -m ruff check .
python -m ruff format --check .
python -m compileall -q .
```

`--validate-only` requires an already completed `PTBR`. It checks the source-manifest relationship,
exact file set and hashes, duplicate JSON keys, non-translatable structure, runtime metadata,
byte-identical TXT files, non-empty target units, protected technical tokens, and PT-BR gender
metadata.

## Translation modes

Normal translation resumes a compatible generation by default:

```powershell
python translate_project.py --input EN\translations\ptbr --output PTBR --verbose
```

Start a fresh generation while still writing durable checkpoints:

```powershell
python translate_project.py --no-resume --input EN\translations\ptbr --output PTBR
```

Review a complete compatible translation:

```powershell
python translate_project.py --review --input EN\translations\ptbr --output PTBR
```

Retranslate every original source unit without providing previous target text:

```powershell
python translate_project.py --remake --no-resume --input EN\translations\ptbr --output PTBR
```

Use `python translate_project.py --help` for all wired limits and switches. Defaults are 10 units,
2,000 source-plus-unit-context characters, five translation workers, five total provider requests,
at least four translation slots, three retries, a 300-second timeout, and a 32,768-unit local
response ceiling. The system message, JSON envelope, and glossary view are additional to the batch
character counter.

During an interactive provider run, progress is refreshed in place on one terminal line with a
bar, percentage, accepted and total units, current throughput, and an `HH:MM:SS` ETA. Partial
checkpoint commits also refresh the estimate. The line is closed cleanly before the final success
or failure message. `--verbose` retains the structured event log; redirected output never receives
carriage-return progress control characters.

## Game context and localization register

Every translation and review request carries a canonical Soulash 2 profile in its system message.
The profile is based on the game's [official Steam description](https://store.steampowered.com/app/2399160/Soulash_2/):
the post-divine dark-fantasy setting; procedural world and history; civilizations, settlements,
economy, families, and wars; exploration, turn-based combat, crafting, trading, building,
settlement leadership, conquest, legacy, and the different consequences of death.

The prompt also distinguishes compact UI, mechanically exact tooltips and simulation text,
idiomatic dialogue, and more expressive histories or world events. Dark fantasy is not treated as
permission to make neutral menus archaic or every line ominous. Lore, speaker traits, gender, and
proper-name translations cannot be invented. Exact source text, structural unit context, and
locked or confirmed glossary terms take precedence over broad setting assumptions.

`--project-context` adds run-specific information; it does not replace the canonical profile. A
prompt-policy revision is part of checkpoint compatibility, so results accepted under an older
context policy are not silently resumed under the current one.

## Safety architecture

- JSON source files are immutable reconstruction skeletons; model output never becomes a file
  template.
- Stable unit IDs combine file path, structural path, declared list IDs, duplicate-ID occurrence,
  and content hashes where explicit IDs do not exist.
- Engine variables, brace substitutions, verified printf specifiers, color markup, line breaks,
  numeric expressions, percentages, and control glyphs are opaque tokens.
- Independent tokens may move for natural PT-BR grammar. Paired color tags must remain balanced and
  nested. Multiplicity is exact; missing, duplicated, changed, leaked, or invented syntax fails.
- Restored text is tokenized again before acceptance so token movement cannot silently merge or
  reinterpret technical syntax. Legacy checkpoints that fail this invariant are selectively retried.
- Entity noun gender and feminine resource affixes use Soulash 2's verified translation metadata.
  Custom selector generation is disabled because this source does not contain that grammar.
- Operation-specific schemas constrain translation, review, and glossary responses. Duplicate keys,
  wrapping prose, extra IDs, invalid types, and incomplete envelopes fail locally.
- Valid IDs from a partial response are committed immediately on the main thread. Only invalid or
  missing IDs retry; deterministic failures split under one bounded root budget.
- Translation and glossary requests share one capacity controller. Translation has priority and the
  glossary worker can occupy at most one default slot.
- Generations, accepted units, compatibility fingerprints, and glossary revisions use project-local
  SQLite databases in WAL mode.
- Complete output is rebuilt in staging, validated, and promoted only when every required unit is
  accepted. An existing valid output is moved to a timestamped `PTBR.previous-*` directory first.

## Smart glossary

The glossary supports `locked`, `confirmed`, `provisional`, `challenged`, `conflicted`, `preserved`,
and `deprecated` states. Requests receive only a bounded relevant view. Ordinary source/target
differences do not create worker tasks; accepted recurring-term decisions, conflicts, meaningful
inconsistency, or manual candidates do. A normal glossary backlog never blocks a complete
translation publication. `--wait-for-glossary` explicitly drains pending tasks and fails if the
worker cannot make progress.

## Platform commands

Recommended Windows command:

```powershell
python translate_project.py --input EN\translations\ptbr --output PTBR --verbose
```

Recommended Linux or macOS command:

```bash
python3 translate_project.py --input EN/translations/ptbr --output PTBR --verbose
```

## Current limitations

- The generated PT-BR localization has not yet received an in-game font/layout, linguistic, or
  gameplay validation pass.
- The mod metadata currently targets the verified game version `0.10.1`; refresh and revalidate it
  when Soulash 2 updates.
